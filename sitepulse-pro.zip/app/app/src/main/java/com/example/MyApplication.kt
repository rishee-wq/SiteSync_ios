package com.example

import android.app.Application
import com.google.firebase.FirebaseApp
import com.google.firebase.appcheck.FirebaseAppCheck
import com.google.firebase.appcheck.recaptcha.RecaptchaEnterpriseProviderFactory

class MyApplication : Application() {
    override fun onCreate() {
        super.onCreate()
        
        FirebaseApp.initializeApp(this)
        
        val firebaseAppCheck = FirebaseAppCheck.getInstance()
        firebaseAppCheck.installAppCheckProviderFactory(
            RecaptchaEnterpriseProviderFactory.getInstance("6Lf5jnUtAAAAANZCWsNQS8CG-yGV_TZXjQEtJA2v")
        )
    }
}
