package com.example.model

enum class TicketPriority {
    LOW, MEDIUM, URGENT
}

enum class TicketStatus {
    SUBMITTED, IN_REVIEW, IN_DEVELOPMENT, DEPLOYED
}

data class Ticket(
    val ticketId: String = "",
    val clientUid: String = "",
    val type: String = "", // Change Request, Design Update, Critical Downtime, Feature Addition
    val title: String = "",
    val description: String = "",
    val priority: TicketPriority = TicketPriority.LOW,
    val status: TicketStatus = TicketStatus.SUBMITTED,
    val attachments: List<String> = emptyList(),
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
)
