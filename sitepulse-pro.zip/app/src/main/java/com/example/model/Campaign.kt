package com.example.model

enum class CampaignStatus {
    DRAFT, PENDING_APPROVAL, ACTIVE, COMPLETED, REJECTED
}

data class Campaign(
    val campaignId: String = "",
    val clientUid: String = "",
    val title: String = "",
    val bannerUrl: String = "",
    val ctaLink: String = "",
    val startDate: Long = System.currentTimeMillis(),
    val endDate: Long = System.currentTimeMillis() + 86400000L * 7,
    val status: CampaignStatus = CampaignStatus.DRAFT,
    val clicks: Int = 0
)
