package com.example.model

data class ChatMessage(
    val messageId: String = "",
    val channelId: String = "",
    val senderUid: String = "",
    val senderName: String = "",
    val senderRole: UserRole = UserRole.CLIENT,
    val text: String = "",
    val timestamp: Long = System.currentTimeMillis(),
    val isRead: Boolean = false,
    val attachmentUrl: String? = null,
    val attachmentType: String? = null
)

data class ChatChannel(
    val channelId: String = "",
    val clientUid: String = "",
    val clientName: String = "",
    val agencyUid: String = "agency_primary",
    val agencyName: String = "SitePulse Partner Agency",
    val lastMessage: String = "",
    val lastMessageTime: Long = System.currentTimeMillis(),
    val clientUnreadCount: Int = 0,
    val agencyUnreadCount: Int = 0
)
