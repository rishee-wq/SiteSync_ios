package com.example.model

enum class SiteCategory(val displayName: String, val orderLabel: String) {
    FOOD_DELIVERY("Food & Restaurant", "Orders Placed"),
    SHOE_ECOMMERCE("Shoe & Fashion Store", "Items Sold"),
    SERVICE_AGENCY("Professional Services", "Consultations Booked"),
    CUSTOM("General E-Commerce", "Conversions")
}

data class AutomationFlow(
    val flowId: String = "",
    val name: String = "",
    val description: String = "",
    val isEnabled: Boolean = true,
    val triggerType: String = "Traffic Surge"
)

data class Website(
    val domainId: String = "",
    val clientUid: String = "",
    val domainUrl: String = "",
    val siteName: String = "",
    val siteCategory: SiteCategory = SiteCategory.FOOD_DELIVERY,
    val uptimeStatus: Boolean = true,
    val liveVisitorsCount: Int = 142,
    val dailyTotalVisitors: Int = 3840,
    val activeOrdersCount: Int = 28,
    val totalRevenue: Double = 4250.00,
    val conversionRate: Double = 3.8,
    val speedScore: Int = 98,
    val peakCrowdHours: String = "12:00 PM - 2:30 PM",
    val activeBannerConfig: String = "Flash 20% Off Promotion",
    val topItems: List<String> = listOf("Artisanal Pizza Combo", "Truffle Pasta", "Gelato Special"),
    val automations: List<AutomationFlow> = listOf(
        AutomationFlow("a1", "Auto-Surge Smart Banner", "Triggers high-converting promotion during peak traffic hours", true),
        AutomationFlow("a2", "Cart Abandonment Recovery", "Sends instant reminder notifications to shoppers who leave items", true),
        AutomationFlow("a3", "AI Support Bot Routing", "Handles client inquiries instantly with direct escalation to agency", true)
    )
)

