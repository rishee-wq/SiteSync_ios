package com.example.model

enum class UserRole {
    CLIENT,
    PROVIDER
}

data class User(
    val uid: String = "",
    val name: String = "",
    val email: String = "",
    val role: UserRole = UserRole.CLIENT,
    val companyName: String = "",
    val domainUrl: String = "",
    val profilePic: String = "",
    val createdAt: Long = System.currentTimeMillis()
)
