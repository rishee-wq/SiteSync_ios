package com.example.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.ChatRepository
import com.example.model.ChatChannel
import com.example.model.ChatMessage
import com.example.model.User
import com.example.model.UserRole
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

class ChatViewModel(
    private val chatRepository: ChatRepository = ChatRepository()
) : ViewModel() {

    private val _currentUser = MutableStateFlow<User?>(null)

    val channels: StateFlow<List<ChatChannel>> = _currentUser.flatMapLatest { user ->
        chatRepository.getChannelsForUser(user)
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    private val _selectedChannel = MutableStateFlow<ChatChannel?>(null)
    val selectedChannel: StateFlow<ChatChannel?> = _selectedChannel.asStateFlow()

    val messages: StateFlow<List<ChatMessage>> = _selectedChannel.flatMapLatest { channel ->
        if (channel != null) {
            chatRepository.getMessagesForChannel(channel.channelId)
        } else {
            flowOf(emptyList())
        }
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    private val _inputText = MutableStateFlow("")
    val inputText: StateFlow<String> = _inputText.asStateFlow()

    private val _isSending = MutableStateFlow(false)
    val isSending: StateFlow<Boolean> = _isSending.asStateFlow()

    init {
        // Auto-select first channel when channels load
        viewModelScope.launch {
            channels.collect { channelList ->
                if (_selectedChannel.value == null && channelList.isNotEmpty()) {
                    _selectedChannel.value = channelList.first()
                }
            }
        }
    }

    fun setUser(user: User?) {
        _currentUser.value = user
    }

    fun selectChannel(channel: ChatChannel) {
        _selectedChannel.value = channel
    }

    fun updateInputText(text: String) {
        _inputText.value = text
    }

    fun sendMessage(sender: User?) {
        val textToSend = _inputText.value.trim()
        if (textToSend.isBlank()) return

        val channel = _selectedChannel.value ?: return
        val effectiveUser = sender ?: User(
            uid = "dummy_user",
            name = "Client User",
            role = UserRole.CLIENT,
            companyName = "Acme Corp"
        )

        viewModelScope.launch {
            _isSending.value = true
            _inputText.value = ""
            chatRepository.sendMessage(
                channelId = channel.channelId,
                sender = effectiveUser,
                text = textToSend
            )
            _isSending.value = false
        }
    }

    fun sendQuickReply(quickText: String, sender: User?) {
        _inputText.value = quickText
        sendMessage(sender)
    }
}
