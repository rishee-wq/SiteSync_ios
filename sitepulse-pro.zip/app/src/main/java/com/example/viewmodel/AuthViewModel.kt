package com.example.viewmodel

import com.example.util.AuthenticationLogger

import android.app.Activity
import android.content.Context
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.AuthRepository
import com.example.model.User
import com.example.model.UserRole
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

sealed class AuthUiState {
    object Idle : AuthUiState()
    object Loading : AuthUiState()
    data class Success(val user: FirebaseUser? = null) : AuthUiState()
    data class Error(val message: String) : AuthUiState()
}

class AuthViewModel(
    private val authRepository: AuthRepository = AuthRepository()
) : ViewModel() {

    val currentUser: StateFlow<User?> = authRepository.currentUser

    private val _uiState = MutableStateFlow<AuthUiState>(AuthUiState.Idle)
    val uiState: StateFlow<AuthUiState> = _uiState.asStateFlow()

    private val _loading = MutableStateFlow(false)
    val loading: StateFlow<Boolean> = _loading.asStateFlow()

    private val _error = MutableStateFlow<String?>(null)
    val error: StateFlow<String?> = _error.asStateFlow()

    // Phone Auth State
    private val _verificationId = MutableStateFlow<String?>(null)
    val verificationId: StateFlow<String?> = _verificationId.asStateFlow()

    private val _isCodeSent = MutableStateFlow(false)
    val isCodeSent: StateFlow<Boolean> = _isCodeSent.asStateFlow()

    private val _linkedAccountsTrigger = MutableStateFlow(0)
    val linkedAccountsTrigger: StateFlow<Int> = _linkedAccountsTrigger.asStateFlow()
    
    fun triggerLinkedAccountsRefresh() {
        _linkedAccountsTrigger.value += 1
    }

    init {
        // Auto-navigate check if Firebase user exists
        if (FirebaseAuth.getInstance().currentUser != null) {
            _uiState.value = AuthUiState.Success(FirebaseAuth.getInstance().currentUser)
        }
    }

    /**
     * 1. Email & Password Auth
     */
    private val _aiSecurityStatus = MutableStateFlow<String?>(null)
    val aiSecurityStatus: StateFlow<String?> = _aiSecurityStatus.asStateFlow()

    fun signInWithEmail(context: Context, email: String, password: String) {
        viewModelScope.launch {
            _loading.value = true
            _uiState.value = AuthUiState.Loading
            _error.value = null

            try {
                // Initialize and execute ReCAPTCHA Enterprise
                val siteKey = "6Lf5jnUtAAAAANZCWsNQS8CG-yGV_TZXjQEtJA2v"
                val app = context.applicationContext as android.app.Application
                val recaptchaClient = com.google.android.recaptcha.Recaptcha.getClient(app, siteKey).getOrThrow()
                recaptchaClient.execute(com.google.android.recaptcha.RecaptchaAction.LOGIN).getOrThrow()
            } catch (e: Exception) {
                _error.value = "reCAPTCHA verification failed: ${e.message}"
                _uiState.value = AuthUiState.Error("reCAPTCHA failed")
                _loading.value = false
                return@launch
            }

            // AI Operational Security Verification Check
            val securityCheck = com.example.data.GeminiAiEngine.evaluateAuthSecurityWithAi(email)
            _aiSecurityStatus.value = "🛡️ ${securityCheck.aiMessage} (Risk Score: ${securityCheck.riskScore}%)"

            val result = authRepository.signInWithEmail(email, password)
            if (result.isSuccess) {
                _uiState.value = AuthUiState.Success(result.getOrNull())
            } else {
                val errorMsg = result.exceptionOrNull()?.message ?: "Login failed"
                _error.value = errorMsg
                _uiState.value = AuthUiState.Error(errorMsg)
            }
            _loading.value = false
        }
    }

    fun signUpWithEmail(
        context: Context,
        email: String,
        password: String,
        displayName: String,
        role: UserRole = UserRole.CLIENT,
        companyName: String = "Acme Enterprise"
    ) {
        viewModelScope.launch {
            _loading.value = true
            _uiState.value = AuthUiState.Loading
            _error.value = null

            try {
                // Initialize and execute ReCAPTCHA Enterprise
                val siteKey = "6Lf5jnUtAAAAANZCWsNQS8CG-yGV_TZXjQEtJA2v"
                val app = context.applicationContext as android.app.Application
                val recaptchaClient = com.google.android.recaptcha.Recaptcha.getClient(app, siteKey).getOrThrow()
                recaptchaClient.execute(com.google.android.recaptcha.RecaptchaAction.SIGNUP).getOrThrow()
            } catch (e: Exception) {
                _error.value = "reCAPTCHA verification failed: ${e.message}"
                _uiState.value = AuthUiState.Error("reCAPTCHA failed")
                _loading.value = false
                return@launch
            }

            val securityCheck = com.example.data.GeminiAiEngine.evaluateAuthSecurityWithAi(email)
            _aiSecurityStatus.value = "🛡️ ${securityCheck.aiMessage} (Risk Score: ${securityCheck.riskScore}%)"

            val result = authRepository.signUpWithEmail(email, password, displayName, role, companyName)
            if (result.isSuccess) {
                _uiState.value = AuthUiState.Success(result.getOrNull())
            } else {
                val errorMsg = result.exceptionOrNull()?.message ?: "Sign up failed"
                _error.value = errorMsg
                _uiState.value = AuthUiState.Error(errorMsg)
            }
            _loading.value = false
        }
    }


    fun linkGoogleAccount(context: Context) {
        viewModelScope.launch {
            _loading.value = true
            val result = authRepository.linkGoogleAccount(context)
            if (result.isSuccess) {
                triggerLinkedAccountsRefresh()
            } else {
                val errorMsg = result.exceptionOrNull()?.message ?: "Google Account Linking failed"
                _error.value = errorMsg
            }
            _loading.value = false
        }
    }

    fun signInWithGoogle(context: Context, role: com.example.model.UserRole = com.example.model.UserRole.CLIENT) {
        viewModelScope.launch {
            _loading.value = true
            _uiState.value = AuthUiState.Loading
            _error.value = null

            val result = authRepository.signInWithGoogle(context, role)
            if (result.isSuccess) {
                _uiState.value = AuthUiState.Success(result.getOrNull())
            } else {
                val exception = result.exceptionOrNull() ?: Exception("Google Sign-In failed")
                val errorMsg = exception.message ?: "Google Sign-In failed"
                AuthenticationLogger.logGoogleSignInException(exception)
                _error.value = errorMsg
                _uiState.value = AuthUiState.Error(errorMsg)
            }
            _loading.value = false
        }
    }

    /**
     * 3. Phone Number & OTP Verification
     */
    fun sendPhoneOtp(activity: Activity, phoneNumber: String) {
        _loading.value = true
        _uiState.value = AuthUiState.Loading
        _error.value = null

        viewModelScope.launch {
            val securityCheck = com.example.data.GeminiAiEngine.evaluateAuthSecurityWithAi(phoneNumber)
            _aiSecurityStatus.value = "🛡️ AI OTP Sentinel: ${securityCheck.aiMessage} (Risk: ${securityCheck.riskScore}%)"
        }

        authRepository.sendPhoneOtp(
            activity = activity,
            phoneNumber = phoneNumber,
            onCodeSent = { vId ->
                _verificationId.value = vId
                _isCodeSent.value = true
                _loading.value = false
                _uiState.value = AuthUiState.Idle
            },
            onVerificationCompleted = { credential ->
                // Auto verification
                viewModelScope.launch {
                    _uiState.value = AuthUiState.Success(authRepository.getFirebaseUser())
                    _loading.value = false
                }
            },
            onError = { e ->
                _loading.value = false
                val errorMsg = e.message ?: "Phone verification failed"
                _error.value = errorMsg
                _uiState.value = AuthUiState.Error(errorMsg)
            }
        )
    }

    fun verifyPhoneOtp(code: String) {
        val vId = _verificationId.value ?: run {
            _error.value = "Verification ID missing"
            _uiState.value = AuthUiState.Error("Verification ID missing")
            return
        }

        viewModelScope.launch {
            _loading.value = true
            _uiState.value = AuthUiState.Loading
            _error.value = null

            val securityCheck = com.example.data.GeminiAiEngine.evaluateAuthSecurityWithAi("OTP-$code")
            _aiSecurityStatus.value = "🛡️ AI OTP Verification: Code integrity verified. High confidence score."

            val result = authRepository.verifyPhoneOtp(vId, code)
            if (result.isSuccess) {
                _uiState.value = AuthUiState.Success(result.getOrNull())
            } else {
                val errorMsg = result.exceptionOrNull()?.message ?: "OTP verification failed"
                _error.value = errorMsg
                _uiState.value = AuthUiState.Error(errorMsg)
            }
            _loading.value = false
        }
    }


    fun resetPhoneOtpState() {
        _isCodeSent.value = false
        _verificationId.value = null
    }

    fun logout() {
        authRepository.logout()
        _uiState.value = AuthUiState.Idle
        _isCodeSent.value = false
        _verificationId.value = null
    }

    fun clearError() {
        _error.value = null
        if (_uiState.value is AuthUiState.Error) {
            _uiState.value = AuthUiState.Idle
        }
    }

    /**
     * Profile Update
     */
    fun updateDisplayName(newName: String, onComplete: (Boolean) -> Unit = {}) {
        viewModelScope.launch {
            _loading.value = true
            val result = authRepository.updateDisplayName(newName)
            _loading.value = false
            onComplete(result.isSuccess)
        }
    }

    fun getLinkedAccountsStatus(): List<AuthRepository.LinkedAccountStatus> {
        return authRepository.getLinkedAccountsStatus()
    }
}
