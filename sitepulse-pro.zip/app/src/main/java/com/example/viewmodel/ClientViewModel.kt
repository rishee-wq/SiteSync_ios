package com.example.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.FirestoreRepository
import com.example.model.AutomationFlow
import com.example.model.Campaign
import com.example.model.SiteCategory
import com.example.model.Ticket
import com.example.model.TicketPriority
import com.example.model.Website
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class ClientViewModel(
    private val clientUid: String,
    private val firestoreRepository: FirestoreRepository = FirestoreRepository()
) : ViewModel() {

    val website: StateFlow<Website?> = firestoreRepository.getWebsite(clientUid)
        .stateIn(
            viewModelScope,
            SharingStarted.WhileSubscribed(5000),
            Website(
                domainId = "dom_$clientUid",
                clientUid = clientUid,
                siteName = "Tasty Bites Bistro",
                domainUrl = "www.tastybitesbistro.com",
                siteCategory = SiteCategory.FOOD_DELIVERY,
                uptimeStatus = true,
                liveVisitorsCount = 148,
                dailyTotalVisitors = 3920,
                activeOrdersCount = 34,
                totalRevenue = 4850.00,
                conversionRate = 4.2,
                speedScore = 98,
                peakCrowdHours = "12:00 PM - 2:30 PM & 6:30 PM - 9:00 PM",
                topItems = listOf("Woodfired Pepperoni Pizza", "Garlic Butter Wings", "Tiramisu Delight")
            )
        )

    val tickets: StateFlow<List<Ticket>> = firestoreRepository.getTicketsForClient(clientUid)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val campaigns: StateFlow<List<Campaign>> = firestoreRepository.getCampaignsForClient(clientUid)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val _loading = MutableStateFlow(false)
    val loading: StateFlow<Boolean> = _loading.asStateFlow()

    private val _error = MutableStateFlow<String?>(null)
    val error: StateFlow<String?> = _error.asStateFlow()

    private val _analysisSuccess = MutableStateFlow(false)
    val analysisSuccess: StateFlow<Boolean> = _analysisSuccess.asStateFlow()

    fun createTicket(title: String, description: String, type: String, priority: TicketPriority) {
        viewModelScope.launch {
            _loading.value = true
            val ticket = Ticket(
                clientUid = clientUid,
                title = title,
                description = description,
                type = type,
                priority = priority
            )
            firestoreRepository.createTicket(ticket).onFailure {
                _error.value = it.message
            }
            _loading.value = false
        }
    }

    fun createCampaign(campaign: Campaign) {
        viewModelScope.launch {
            _loading.value = true
            firestoreRepository.createCampaign(campaign).onFailure {
                _error.value = it.message
            }
            _loading.value = false
        }
    }

    fun addOrAnalyzeWebsite(
        url: String,
        name: String,
        category: SiteCategory
    ) {
        viewModelScope.launch {
            _loading.value = true
            _analysisSuccess.value = false

            val aiResult = com.example.data.GeminiAiEngine.analyzeWebsiteWithAi(
                domainUrl = url,
                siteName = name,
                category = category
            )

            val (liveVis, totalVis, orders, rev) = when (category) {
                SiteCategory.FOOD_DELIVERY -> Tuple4(184, 4200, 48, 5920.0)
                SiteCategory.SHOE_ECOMMERCE -> Tuple4(310, 8500, 72, 12840.0)
                SiteCategory.SERVICE_AGENCY -> Tuple4(92, 1850, 14, 18400.0)
                SiteCategory.CUSTOM -> Tuple4(140, 3100, 26, 3900.0)
            }

            val newWebsite = Website(
                domainId = "dom_${System.currentTimeMillis()}",
                clientUid = clientUid,
                domainUrl = url,
                siteName = name,
                siteCategory = category,
                uptimeStatus = true,
                liveVisitorsCount = liveVis,
                dailyTotalVisitors = totalVis,
                activeOrdersCount = orders,
                totalRevenue = rev,
                conversionRate = aiResult.conversionScore / 20.0,
                speedScore = aiResult.seoScore,
                peakCrowdHours = aiResult.crowdSurgeForecast,
                activeBannerConfig = aiResult.recommendedPromo,
                topItems = aiResult.topItems
            )

            firestoreRepository.saveWebsite(newWebsite)
            _analysisSuccess.value = true
            _loading.value = false
        }
    }

    fun reAnalyzeCurrentWebsite() {
        val current = website.value ?: return
        viewModelScope.launch {
            _loading.value = true
            val aiResult = com.example.data.GeminiAiEngine.analyzeWebsiteWithAi(
                domainUrl = current.domainUrl,
                siteName = current.siteName,
                category = current.siteCategory
            )

            val updated = current.copy(
                conversionRate = aiResult.conversionScore / 20.0,
                speedScore = aiResult.seoScore,
                peakCrowdHours = aiResult.crowdSurgeForecast,
                activeBannerConfig = aiResult.recommendedPromo,
                topItems = aiResult.topItems
            )
            firestoreRepository.saveWebsite(updated)
            _loading.value = false
        }
    }


    fun toggleAutomationFlow(flowId: String) {
        val current = website.value ?: return
        val updatedAutomations = current.automations.map {
            if (it.flowId == flowId) it.copy(isEnabled = !it.isEnabled) else it
        }
        val updatedWebsite = current.copy(automations = updatedAutomations)
        viewModelScope.launch {
            firestoreRepository.saveWebsite(updatedWebsite)
        }
    }

    fun clearError() {
        _error.value = null
        _analysisSuccess.value = false
    }
}

private data class Tuple4<A, B, C, D>(
    val a: A, val b: B, val c: C, val d: D
)


