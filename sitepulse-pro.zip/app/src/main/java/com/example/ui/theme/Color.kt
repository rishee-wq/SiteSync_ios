package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val DeepZinc = Color(0xFF09090B)
val SurfaceDark = Color(0xFF131316)
val GlassCardBg = Color(0x1AFFFFFF)
val GlassCardBorder = Color(0x26FFFFFF)
val SurfaceContainer = Color(0xFF1F1F22)
val SurfaceHigh = Color(0xFF2A2A2D)

val NeonPurple = Color(0xFFD0BCFF)
val NeonPurplePrimary = Color(0xFFA078FF)
val NeonCyan = Color(0xFF4CD7F6)
val NeonCyanDark = Color(0xFF03B5D3)

val TextPrimary = Color(0xFFE4E1E6)
val TextSecondary = Color(0xFFCBC3D7)
val TextMuted = Color(0xFF958EA0)

val StatusSuccess = Color(0xFF4ADE80)
val StatusWarning = Color(0xFFF9A826)
val StatusError = Color(0xFFFFB4AB)

