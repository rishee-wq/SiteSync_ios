package com.example.ui.screens.client

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateContentSize
import androidx.compose.animation.core.tween
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.model.AutomationFlow
import com.example.model.SiteCategory
import com.example.model.User
import kotlinx.coroutines.launch
import kotlinx.coroutines.delay
import com.example.model.Website
import com.example.viewmodel.ClientViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ClientDashboardScreen(
    onSignOut: () -> Unit,
    onNavigateToProfile: () -> Unit = {},
    onNavigateToChat: () -> Unit = {},
    user: User?,
) {
    val clientViewModel = remember(user?.uid) {
        if (user != null) ClientViewModel(user.uid) else null
    }

    val website by clientViewModel?.website?.collectAsState(initial = null) ?: remember { mutableStateOf(null) }
    val isAnalyzing by clientViewModel?.loading?.collectAsState() ?: remember { mutableStateOf(false) }
    val analysisSuccess by clientViewModel?.analysisSuccess?.collectAsState() ?: remember { mutableStateOf(false) }

    var selectedTab by remember { mutableStateOf(0) }
    var showAddWebsiteDialog by remember { mutableStateOf(false) }
    var showCreateTicketDialog by remember { mutableStateOf(false) }
    var showCreatePromoDialog by remember { mutableStateOf(false) }

    val deepZincBg = Color(0xFF09090B)
    val glassBorder = Color(0x26FFFFFF)

    com.example.ui.components.ParticleBackground(
        modifier = Modifier.fillMaxSize(),
        backgroundColor = deepZincBg,
        particleColor = Color(0xFFA078FF)
    ) {
        Scaffold(
            topBar = {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color(0xFF131316).copy(alpha = 0.95f))
                    .statusBarsPadding()
                    .padding(horizontal = 16.dp, vertical = 12.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .clip(CircleShape)
                            .background(
                                Brush.linearGradient(
                                    listOf(Color(0xFFA078FF), Color(0xFF4CD7F6))
                                )
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Public,
                            contentDescription = "Logo",
                            tint = Color(0xFF09090B),
                            modifier = Modifier.size(20.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(
                            text = "SitePulse AI",
                            fontWeight = FontWeight.ExtraBold,
                            fontSize = 17.sp,
                            color = Color(0xFFD0BCFF),
                            letterSpacing = (-0.5).sp
                        )
                        Text(
                            text = "Real-time Crowd & Commerce Grid",
                            fontSize = 10.sp,
                            color = Color(0xFF958EA0)
                        )
                    }
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = { showAddWebsiteDialog = true }) {
                        Icon(
                            imageVector = Icons.Default.Add,
                            contentDescription = "Analyze New Site",
                            tint = Color(0xFF4CD7F6)
                        )
                    }
                    IconButton(onClick = { selectedTab = 1 }) {
                        Icon(
                            imageVector = Icons.Default.Forum,
                            contentDescription = "Agency Partner Chat",
                            tint = Color(0xFFD0BCFF)
                        )
                    }
                    IconButton(onClick = onNavigateToProfile) {
                        Icon(
                            imageVector = Icons.Default.AccountCircle,
                            contentDescription = "User Profile",
                            tint = Color(0xFFE4E1E6)
                        )
                    }
                }
            }
        },
        bottomBar = {
            NavigationBar(
                containerColor = Color(0xFF131316).copy(alpha = 0.95f),
                tonalElevation = 0.dp,
                modifier = Modifier.border(width = 1.dp, color = glassBorder)
            ) {
                val navItems = listOf(
                    Triple(0, Icons.Default.Home, "HOME"),
                    Triple(1, Icons.Default.Forum, "CHAT"),
                    Triple(2, Icons.Default.Timeline, "CROWD"),
                    Triple(3, Icons.Default.Notifications, "ALERTS"),
                    Triple(4, Icons.Default.Settings, "SETTINGS")
                )

                navItems.forEach { (index, icon, label) ->
                    val isSelected = selectedTab == index
                    NavigationBarItem(
                        icon = {
                            Icon(
                                icon,
                                contentDescription = label,
                                tint = if (isSelected) Color(0xFF4CD7F6) else Color(0xFF958EA0)
                            )
                        },
                        label = {
                            Text(
                                label,
                                fontSize = 10.sp,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                color = if (isSelected) Color(0xFF4CD7F6) else Color(0xFF958EA0)
                            )
                        },
                        selected = isSelected,
                        onClick = { selectedTab = index },
                        colors = NavigationBarItemDefaults.colors(
                            indicatorColor = Color.Transparent
                        )
                    )
                }
            }
        },
        containerColor = Color.Transparent
    ) { paddingValues ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .imePadding()
        ) {
            AnimatedContent(
                targetState = selectedTab,
                transitionSpec = {
                    if (targetState > initialState) {
                        (slideInHorizontally(animationSpec = tween(300)) { width -> width } + fadeIn(animationSpec = tween(300))) togetherWith
                        (slideOutHorizontally(animationSpec = tween(300)) { width -> -width } + fadeOut(animationSpec = tween(300)))
                    } else {
                        (slideInHorizontally(animationSpec = tween(300)) { width -> -width } + fadeIn(animationSpec = tween(300))) togetherWith
                        (slideOutHorizontally(animationSpec = tween(300)) { width -> width } + fadeOut(animationSpec = tween(300)))
                    }
                },
                label = "MaterialMotionTabTransition"
            ) { targetTab ->
                when (targetTab) {
                    0 -> ClientHomeTabContent(
                        user = user,
                        website = website,
                        onOpenAddSite = { showAddWebsiteDialog = true },
                        onOpenCreateTicket = { showCreateTicketDialog = true },
                        onOpenCreatePromo = { showCreatePromoDialog = true },
                        onReAnalyzeSite = { clientViewModel?.reAnalyzeCurrentWebsite() },
                        onNavigateToChat = { selectedTab = 1 }
                    )

                    1 -> com.example.ui.screens.chat.ChatScreen(currentUser = user)
                    2 -> ClientCrowdAnalyticsTabContent(
                        website = website,
                        clientViewModel = clientViewModel
                    )
                    3 -> ClientAlertsTabContent()
                    4 -> ClientSettingsTabContent(onSignOut = onSignOut, onNavigateToProfile = onNavigateToProfile)
                }
            }
        }
    }
    }

    if (showAddWebsiteDialog) {
        AnalyzeWebsiteModalDialog(
            isAnalyzing = isAnalyzing,
            analysisSuccess = analysisSuccess,
            onDismiss = {
                showAddWebsiteDialog = false
                clientViewModel?.clearError()
            },
            onAnalyze = { url, name, category ->
                clientViewModel?.addOrAnalyzeWebsite(url, name, category)
            }
        )
    }

    if (showCreateTicketDialog) {
        CreateTicketModalDialog(
            onDismiss = { showCreateTicketDialog = false },
            onSubmit = { title, desc, type, priority ->
                clientViewModel?.createTicket(title, desc, type, priority)
                showCreateTicketDialog = false
            }
        )
    }

    if (showCreatePromoDialog) {
        CreatePromoModalDialog(
            onDismiss = { showCreatePromoDialog = false },
            onSubmit = { title ->
                clientViewModel?.createCampaign(
                    com.example.model.Campaign(
                        clientUid = user?.uid ?: "dummy_client",
                        title = title,
                        status = com.example.model.CampaignStatus.ACTIVE,
                        startDate = System.currentTimeMillis(),
                        endDate = System.currentTimeMillis() + 86400000L * 14
                    )
                )
                showCreatePromoDialog = false
            }
        )
    }
}

@Composable
fun ClientOnboardingDashboard(
    onOpenAddSite: () -> Unit,
    onOpenCreateTicket: () -> Unit,
    onNavigateToChat: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Icon(
            imageVector = Icons.Default.RocketLaunch,
            contentDescription = "Welcome",
            tint = Color(0xFF4CD7F6),
            modifier = Modifier.size(64.dp)
        )
        Spacer(modifier = Modifier.height(16.dp))
        Text(
            text = "Welcome to SitePulse",
            fontSize = 24.sp,
            fontWeight = FontWeight.Bold,
            color = Color.White
        )
        Spacer(modifier = Modifier.height(8.dp))
        Text(
            text = "To unlock analytics and insights, please add your website. You can also request a service or talk to an agent right away.",
            fontSize = 14.sp,
            color = Color(0xFFCBC3D7),
            textAlign = androidx.compose.ui.text.style.TextAlign.Center
        )
        Spacer(modifier = Modifier.height(32.dp))

        Button(
            onClick = onOpenAddSite,
            modifier = Modifier.fillMaxWidth().height(50.dp),
            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFA078FF)),
            shape = RoundedCornerShape(12.dp)
        ) {
            Icon(Icons.Default.Add, contentDescription = null, tint = Color.White)
            Spacer(modifier = Modifier.width(8.dp))
            Text("Add New Website", color = Color.White, fontWeight = FontWeight.Bold)
        }

        Spacer(modifier = Modifier.height(16.dp))

        Button(
            onClick = onOpenCreateTicket,
            modifier = Modifier.fillMaxWidth().height(50.dp),
            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF4CD7F6)),
            shape = RoundedCornerShape(12.dp)
        ) {
            Icon(Icons.Default.BugReport, contentDescription = null, tint = Color(0xFF09090B))
            Spacer(modifier = Modifier.width(8.dp))
            Text("Request for Service", color = Color(0xFF09090B), fontWeight = FontWeight.Bold)
        }

        Spacer(modifier = Modifier.height(16.dp))

        OutlinedButton(
            onClick = onNavigateToChat,
            modifier = Modifier.fillMaxWidth().height(50.dp),
            border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFD0BCFF)),
            shape = RoundedCornerShape(12.dp)
        ) {
            Icon(Icons.Default.Forum, contentDescription = null, tint = Color(0xFFD0BCFF))
            Spacer(modifier = Modifier.width(8.dp))
            Text("Talk to Agent", color = Color(0xFFD0BCFF), fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
fun ClientHomeTabContent(
    user: User?,
    website: Website?,
    onOpenAddSite: () -> Unit,
    onOpenCreateTicket: () -> Unit = {},
    onOpenCreatePromo: () -> Unit = {},
    onReAnalyzeSite: () -> Unit = {},
    onNavigateToChat: () -> Unit
) {
    if (website == null) {
        ClientOnboardingDashboard(
            onOpenAddSite = onOpenAddSite,
            onOpenCreateTicket = onOpenCreateTicket,
            onNavigateToChat = onNavigateToChat
        )
        return
    }

    val currentWebsite = website

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        contentPadding = PaddingValues(vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Business Header Card
        item {
            GlassCard(modifier = Modifier.fillMaxWidth()) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(
                        modifier = Modifier
                            .weight(1f)
                            .padding(end = 12.dp)
                    ) {
                        Text(
                            text = "CONNECTED SITE",
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF4CD7F6),
                            letterSpacing = 1.sp
                        )
                        Text(
                            text = currentWebsite.siteName,
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFFE4E1E6),
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Text(
                            text = "${currentWebsite.domainUrl} • ${currentWebsite.siteCategory.displayName}",
                            fontSize = 12.sp,
                            color = Color(0xFFCBC3D7),
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }

                    Button(
                        onClick = onOpenAddSite,
                        shape = RoundedCornerShape(12.dp),
                        contentPadding = PaddingValues(horizontal = 14.dp, vertical = 8.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFA078FF))
                    ) {
                        Icon(
                            imageVector = Icons.Default.Add,
                            contentDescription = "Add Site",
                            tint = Color.White,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "Add Site",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White,
                            maxLines = 1
                        )
                    }
                }
            }
        }

        // Cyber Gauge Activity Hero Widget
        item {
            ActivityDashboardHeroCard(website = currentWebsite)
        }

        // AI Engine Site Intelligence & Tracking Card
        item {
            AiSiteIntelligenceTrackingCard(
                website = currentWebsite,
                onReAnalyze = onReAnalyzeSite,
                onOpenPromo = onOpenCreatePromo
            )
        }


        // Live Performance Sparkline & Category Crowd Orders Card
        item {
            WeeklyPerformanceChartCard(website = currentWebsite)
        }

        // Category-Specific Live Orders / Crowd Metrics Grid
        item {
            Text(
                text = "REAL-TIME CROWD TRACKING (${currentWebsite.siteCategory.displayName.uppercase()})",
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                color = Color(0xFF4CD7F6),
                letterSpacing = 1.sp,
                modifier = Modifier.padding(start = 4.dp, top = 4.dp)
            )
        }

        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                MetricGlassCard(
                    modifier = Modifier.weight(1f),
                    title = currentWebsite.siteCategory.orderLabel,
                    value = "${currentWebsite.activeOrdersCount}",
                    change = "+22% peak surge",
                    icon = Icons.Default.ShoppingBag,
                    accentColor = Color(0xFF4CD7F6)
                )

                MetricGlassCard(
                    modifier = Modifier.weight(1f),
                    title = "Conversion Rate",
                    value = "${currentWebsite.conversionRate}%",
                    change = "98/100 Speed Score",
                    icon = Icons.Default.Speed,
                    accentColor = Color(0xFFD0BCFF)
                )
            }
        }

        // Quick Actions Row
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                QuickActionPill(
                    modifier = Modifier.weight(1f),
                    title = "Agency Chat",
                    icon = Icons.Default.Chat,
                    onClick = onNavigateToChat
                )
                QuickActionPill(
                    modifier = Modifier.weight(1f),
                    title = "New Ticket",
                    icon = Icons.Default.BugReport,
                    onClick = onOpenCreateTicket
                )
                QuickActionPill(
                    modifier = Modifier.weight(1f),
                    title = "Add Promo",
                    icon = Icons.Default.Campaign,
                    onClick = onOpenCreatePromo
                )
            }
        }

        // Top Selling / Popular Items List
        item {
            GlassCard(modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "🔥 Top Live Items (${currentWebsite.siteCategory.displayName})",
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFFE4E1E6)
                        )
                        Text(
                            text = "Live Sync",
                            fontSize = 10.sp,
                            color = Color(0xFF4ADE80),
                            fontWeight = FontWeight.Bold
                        )
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    currentWebsite.topItems.forEachIndexed { index, item ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "#${index + 1}",
                                fontWeight = FontWeight.ExtraBold,
                                color = Color(0xFFD0BCFF),
                                fontSize = 13.sp,
                                modifier = Modifier.width(28.dp)
                            )
                            Text(
                                text = item,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Medium,
                                color = Color(0xFFE4E1E6),
                                modifier = Modifier.weight(1f)
                            )
                            Text(
                                text = "High Demand",
                                fontSize = 10.sp,
                                color = Color(0xFF4CD7F6),
                                modifier = Modifier
                                    .clip(RoundedCornerShape(6.dp))
                                    .background(Color(0xFF4CD7F6).copy(alpha = 0.15f))
                                    .padding(horizontal = 8.dp, vertical = 2.dp)
                            )
                        }
                        if (index < currentWebsite.topItems.size - 1) {
                            HorizontalDivider(color = Color(0x1AFFFFFF))
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun ActivityDashboardHeroCard(website: Website) {
    var isExpanded by remember { mutableStateOf(false) }

    GlassCard(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { isExpanded = !isExpanded }
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(20.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Live Crowd & Traffic Gauge",
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFFE4E1E6)
                )
                Icon(
                    imageVector = if (isExpanded) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
                    contentDescription = "Expand Card Details",
                    tint = Color(0xFF4CD7F6)
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Glowing Concentric Activity Ring Canvas
            Box(
                modifier = Modifier.size(160.dp),
                contentAlignment = Alignment.Center
            ) {
                Canvas(modifier = Modifier.fillMaxSize()) {
                    val strokeWidth = 12.dp.toPx()
                    // Outer Ring (Purple)
                    drawArc(
                        color = Color(0xFF353438),
                        startAngle = 135f,
                        sweepAngle = 270f,
                        useCenter = false,
                        style = Stroke(width = strokeWidth)
                    )
                    drawArc(
                        brush = Brush.sweepGradient(listOf(Color(0xFF4CD7F6), Color(0xFFA078FF))),
                        startAngle = 135f,
                        sweepAngle = 210f,
                        useCenter = false,
                        style = Stroke(width = strokeWidth)
                    )

                    // Inner Ring (Cyan)
                    val innerPadding = 20.dp.toPx()
                    drawArc(
                        color = Color(0xFF353438),
                        startAngle = 135f,
                        sweepAngle = 270f,
                        useCenter = false,
                        topLeft = androidx.compose.ui.geometry.Offset(innerPadding, innerPadding),
                        size = androidx.compose.ui.geometry.Size(
                            size.width - innerPadding * 2,
                            size.height - innerPadding * 2
                        ),
                        style = Stroke(width = strokeWidth * 0.8f)
                    )
                    drawArc(
                        color = Color(0xFF4ADE80),
                        startAngle = 135f,
                        sweepAngle = 240f,
                        useCenter = false,
                        topLeft = androidx.compose.ui.geometry.Offset(innerPadding, innerPadding),
                        size = androidx.compose.ui.geometry.Size(
                            size.width - innerPadding * 2,
                            size.height - innerPadding * 2
                        ),
                        style = Stroke(width = strokeWidth * 0.8f)
                    )
                }

                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        text = "${website.liveVisitorsCount}",
                        fontSize = 32.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = Color(0xFFE4E1E6)
                    )
                    Text(
                        text = "ACTIVE NOW",
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF4CD7F6),
                        letterSpacing = 1.sp
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceEvenly
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("Daily Visitors", fontSize = 11.sp, color = Color(0xFF958EA0))
                    Text("${website.dailyTotalVisitors}", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = Color(0xFFD0BCFF))
                }
                Box(modifier = Modifier.height(28.dp).width(1.dp).background(Color(0x26FFFFFF)))
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("Peak Hours", fontSize = 11.sp, color = Color(0xFF958EA0))
                    Text(website.peakCrowdHours, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color(0xFF4CD7F6))
                }
            }

            // Material Motion Expanded Telemetry
            AnimatedVisibility(visible = isExpanded) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 16.dp)
                ) {
                    HorizontalDivider(color = Color(0x26FFFFFF))
                    Spacer(modifier = Modifier.height(12.dp))

                    Text(
                        text = "DETAILED CROWD BREAKDOWN",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF4CD7F6),
                        letterSpacing = 1.sp
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    DetailRowItem("Mobile Visitors", "78% (Smartphone & App)")
                    DetailRowItem("Desktop Visitors", "22% (Web Browsers)")
                    DetailRowItem("Avg Session Length", "4 min 12 sec")
                    DetailRowItem("Server Latency", "18ms (Global CDN)")
                    DetailRowItem("Smart Surge Status", "Active & Monitoring")
                }
            }
        }
    }
}

@Composable
fun WeeklyPerformanceChartCard(website: Website) {
    var isExpanded by remember { mutableStateOf(false) }

    GlassCard(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { isExpanded = !isExpanded }
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "Weekly Performance Curve",
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFFE4E1E6)
                    )
                    Text(
                        text = "Tap for daily conversion breakdown",
                        fontSize = 10.sp,
                        color = Color(0xFF958EA0)
                    )
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = "$${String.format("%.2f", website.totalRevenue)}",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF4ADE80)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Icon(
                        imageVector = if (isExpanded) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
                        contentDescription = "Expand",
                        tint = Color(0xFF4CD7F6)
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Smooth Curve Sparkline Canvas
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(100.dp)
            ) {
                val infiniteTransition = androidx.compose.animation.core.rememberInfiniteTransition()
                val phase by infiniteTransition.animateFloat(
                    initialValue = 0f,
                    targetValue = 2f * Math.PI.toFloat(),
                    animationSpec = androidx.compose.animation.core.infiniteRepeatable(
                        animation = androidx.compose.animation.core.tween(3000, easing = androidx.compose.animation.core.LinearEasing),
                        repeatMode = androidx.compose.animation.core.RepeatMode.Restart
                    )
                )

                Canvas(modifier = Modifier.fillMaxSize()) {
                    val width = size.width
                    val height = size.height
                    
                    val points = List(6) { i ->
                        val base = listOf(0.7f, 0.5f, 0.65f, 0.4f, 0.2f, 0.15f)[i]
                        val offset = (kotlin.math.sin(phase + i * 1.5f) * 0.1f).toFloat()
                        (base + offset) * height
                    }

                    val step = width / (points.size - 1)
                    val path = Path()
                    path.moveTo(0f, points[0])

                    for (i in 0 until points.size - 1) {
                        val x1 = i * step
                        val y1 = points[i]
                        val x2 = (i + 1) * step
                        val y2 = points[i + 1]
                        val cx = (x1 + x2) / 2
                        path.cubicTo(cx, y1, cx, y2, x2, y2)
                    }

                    drawPath(
                        path = path,
                        brush = Brush.horizontalGradient(listOf(Color(0xFFF9A826), Color(0xFF4CD7F6))),
                        style = Stroke(width = 3.dp.toPx())
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                listOf("Mon", "Tue", "Wed", "Thu", "Fri", "Sat").forEach { day ->
                    Text(day, fontSize = 11.sp, color = Color(0xFF958EA0))
                }
            }

            AnimatedVisibility(visible = isExpanded) {
                Column(modifier = Modifier.padding(top = 12.dp)) {
                    HorizontalDivider(color = Color(0x26FFFFFF))
                    Spacer(modifier = Modifier.height(8.dp))
                    DetailRowItem("Monday Orders", "$480.00 (24 orders)")
                    DetailRowItem("Wednesday Peak", "$920.00 (42 orders)")
                    DetailRowItem("Friday Surge", "$1,450.00 (68 orders)")
                    DetailRowItem("Conversion Rate Peak", "${website.conversionRate + 1.2}% (Evening)")
                }
            }
        }
    }
}

@Composable
fun MetricGlassCard(
    modifier: Modifier = Modifier,
    title: String,
    value: String,
    change: String,
    icon: ImageVector,
    accentColor: Color
) {
    var isExpanded by remember { mutableStateOf(false) }

    GlassCard(
        modifier = modifier.clickable { isExpanded = !isExpanded }
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(34.dp)
                        .clip(CircleShape)
                        .background(accentColor.copy(alpha = 0.15f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(icon, contentDescription = null, tint = accentColor, modifier = Modifier.size(18.dp))
                }

                Icon(
                    imageVector = if (isExpanded) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
                    contentDescription = null,
                    tint = Color(0xFF958EA0),
                    modifier = Modifier.size(16.dp)
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            Text(title, fontSize = 11.sp, color = Color(0xFF958EA0))
            Text(value, fontSize = 22.sp, fontWeight = FontWeight.ExtraBold, color = Color(0xFFE4E1E6))
            Spacer(modifier = Modifier.height(2.dp))
            Text(change, fontSize = 10.sp, color = accentColor, fontWeight = FontWeight.Bold)

            AnimatedVisibility(visible = isExpanded) {
                Column(modifier = Modifier.padding(top = 8.dp)) {
                    HorizontalDivider(color = Color(0x1AFFFFFF))
                    Spacer(modifier = Modifier.height(4.dp))
                    Text("vs. Last Week: +14.2%", fontSize = 10.sp, color = Color(0xFFCBC3D7))
                    Text("Top Hour: 1:30 PM", fontSize = 10.sp, color = Color(0xFF4CD7F6))
                }
            }
        }
    }
}

@Composable
fun QuickActionPill(
    modifier: Modifier = Modifier,
    title: String,
    icon: ImageVector,
    onClick: () -> Unit
) {
    GlassCard(
        modifier = modifier.clickable { onClick() }
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.Center
        ) {
            Icon(icon, contentDescription = null, tint = Color(0xFF4CD7F6), modifier = Modifier.size(16.dp))
            Spacer(modifier = Modifier.width(6.dp))
            Text(title, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color(0xFFE4E1E6))
        }
    }
}

@Composable
fun ClientCrowdAnalyticsTabContent(
    website: Website?,
    clientViewModel: ClientViewModel?
) {
    val currentWeb = website ?: Website()

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        contentPadding = PaddingValues(vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Text(
                text = "AUTOMATION FLOWS & CROWD ENGINE",
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                color = Color(0xFF4CD7F6),
                letterSpacing = 1.sp
            )
        }

        // Active Automations List
        items(currentWeb.automations) { flow ->
            AutomationFlowCard(
                flow = flow,
                onToggle = { clientViewModel?.toggleAutomationFlow(flow.flowId) }
            )
        }

        item {
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = "REAL-TIME SITE METRICS SUMMARY",
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                color = Color(0xFFD0BCFF),
                letterSpacing = 1.sp
            )
        }

        item {
            GlassCard(modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(16.dp)) {
                    DetailRowItem("Site Domain", currentWeb.domainUrl)
                    DetailRowItem("Site Category", currentWeb.siteCategory.displayName)
                    DetailRowItem("Speed & Performance Score", "${currentWeb.speedScore} / 100")
                    DetailRowItem("Uptime Status", if (currentWeb.uptimeStatus) "100% Operational" else "Degraded")
                    DetailRowItem("Active Smart Banner", currentWeb.activeBannerConfig)
                }
            }
        }
    }
}

@Composable
fun AutomationFlowCard(
    flow: AutomationFlow,
    onToggle: () -> Unit
) {
    GlassCard(modifier = Modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(40.dp)
                    .clip(CircleShape)
                    .background(
                        if (flow.isEnabled) Color(0xFF4CD7F6).copy(alpha = 0.15f)
                        else Color(0xFF353438)
                    ),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = if (flow.isEnabled) Icons.Default.Bolt else Icons.Default.PowerOff,
                    contentDescription = null,
                    tint = if (flow.isEnabled) Color(0xFF4CD7F6) else Color(0xFF958EA0),
                    modifier = Modifier.size(20.dp)
                )
            }

            Spacer(modifier = Modifier.width(12.dp))

            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = flow.name,
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp,
                    color = Color(0xFFE4E1E6)
                )
                Text(
                    text = flow.description,
                    fontSize = 11.sp,
                    color = Color(0xFFCBC3D7)
                )
            }

            Switch(
                checked = flow.isEnabled,
                onCheckedChange = { onToggle() },
                colors = SwitchDefaults.colors(
                    checkedThumbColor = Color.White,
                    checkedTrackColor = Color(0xFF4CD7F6)
                )
            )
        }
    }
}

@Composable
fun ClientAlertsTabContent() {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        contentPadding = PaddingValues(vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Text(
                text = "REAL-TIME INBOX & SYSTEM ALERTS",
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                color = Color(0xFF4CD7F6),
                letterSpacing = 1.sp
            )
        }

        item {
            AlertGlassCard(
                title = "Crowd Surge Alert - Food Orders +38%",
                subtitle = "Automated Smart Surge banner triggered successfully during lunch hour.",
                time = "2m ago",
                icon = Icons.Default.TrendingUp,
                accentColor = Color(0xFF4ADE80)
            )
        }
        item {
            AlertGlassCard(
                title = "Ticket #8492 Updated by Agency",
                subtitle = "Lead engineer deployed website speed optimizations.",
                time = "15m ago",
                icon = Icons.Default.CheckCircle,
                accentColor = Color(0xFFD0BCFF)
            )
        }
        item {
            AlertGlassCard(
                title = "Weekly Performance Digest Ready",
                subtitle = "Your site converted 142 total sales with 99.98% uptime.",
                time = "1h ago",
                icon = Icons.Default.Assessment,
                accentColor = Color(0xFF4CD7F6)
            )
        }
    }
}

@Composable
fun AlertGlassCard(
    title: String,
    subtitle: String,
    time: String,
    icon: ImageVector,
    accentColor: Color
) {
    GlassCard(modifier = Modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier.padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(38.dp)
                    .clip(CircleShape)
                    .background(accentColor.copy(alpha = 0.15f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(icon, contentDescription = null, tint = accentColor, modifier = Modifier.size(20.dp))
            }
            Spacer(modifier = Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(title, fontWeight = FontWeight.Bold, fontSize = 13.sp, color = Color(0xFFE4E1E6))
                    Text(time, fontSize = 10.sp, color = Color(0xFF958EA0))
                }
                Spacer(modifier = Modifier.height(2.dp))
                Text(subtitle, fontSize = 11.sp, color = Color(0xFFCBC3D7))
            }
        }
    }
}

@Composable
fun ClientSettingsTabContent(
    onSignOut: () -> Unit,
    onNavigateToProfile: () -> Unit
) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        contentPadding = PaddingValues(vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Text(
                text = "ACCOUNT & PLATFORM PREFERENCES",
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                color = Color(0xFF4CD7F6),
                letterSpacing = 1.sp
            )
        }

        item {
            GlassCard(modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(8.dp)) {
                    val themeViewModel = com.example.ui.theme.LocalThemeViewModel.current
                    val isDarkTheme by themeViewModel.isDarkTheme.collectAsStateWithLifecycle(initialValue = androidx.compose.foundation.isSystemInDarkTheme())
                    
                    SettingsRowItem("Profile Information", Icons.Default.Person, onNavigateToProfile)
                    SettingsRowItem("Connected Domain Settings", Icons.Default.Language) {}
                    SettingsRowItem("Notification Protocols", Icons.Default.Notifications) {}
                    SettingsRowItem("Billing & Agency Retainer", Icons.Default.CreditCard) {}
                    
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp, vertical = 12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Settings,
                                contentDescription = "Dark Mode",
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(24.dp)
                            )
                            Spacer(modifier = Modifier.width(16.dp))
                            Text("Dark Mode", color = MaterialTheme.colorScheme.onBackground)
                        }
                        Switch(
                            checked = isDarkTheme ?: androidx.compose.foundation.isSystemInDarkTheme(),
                            onCheckedChange = { themeViewModel.toggleTheme(it) },
                            colors = SwitchDefaults.colors(
                                checkedThumbColor = Color.White,
                                checkedTrackColor = Color(0xFF4CD7F6),
                                uncheckedThumbColor = Color(0xFF8B7D9E),
                                uncheckedTrackColor = Color(0xFF262130)
                            )
                        )
                    }
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(12.dp))
            Button(
                onClick = onSignOut,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp),
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF93000A))
            ) {
                Icon(Icons.Default.ExitToApp, contentDescription = null, tint = Color.White)
                Spacer(modifier = Modifier.width(8.dp))
                Text("Disconnect Session", fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
fun AnalyzeWebsiteModalDialog(
    isAnalyzing: Boolean,
    analysisSuccess: Boolean,
    onDismiss: () -> Unit,
    onAnalyze: (url: String, name: String, category: SiteCategory) -> Unit
) {
    var urlText by remember { mutableStateOf("") }
    var nameText by remember { mutableStateOf("") }
    var selectedCategory by remember { mutableStateOf(SiteCategory.FOOD_DELIVERY) }
    var isVerified by remember { mutableStateOf(false) }
    var showVerificationStep by remember { mutableStateOf(false) }

    LaunchedEffect(analysisSuccess) {
        if (analysisSuccess) {
            kotlinx.coroutines.delay(1000)
            onDismiss()
        }
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Color(0xFF131316),
        title = {
            Text(
                text = "Analyze & Add Website Domain",
                fontWeight = FontWeight.Bold,
                color = Color(0xFFD0BCFF)
            )
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text(
                    text = "Connect a real website URL to start real-time crowd tracking, conversion analytics, and agency support.",
                    fontSize = 12.sp,
                    color = Color(0xFFCBC3D7)
                )

                OutlinedTextField(
                    value = nameText,
                    onValueChange = { nameText = it; isVerified = false; showVerificationStep = false },
                    label = { Text("Business / Site Name") },
                    placeholder = { Text("e.g. YouTube Metrics") },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp)
                )

                OutlinedTextField(
                    value = urlText,
                    onValueChange = { urlText = it; isVerified = false; showVerificationStep = false },
                    label = { Text("Website URL") },
                    placeholder = { Text("e.g. www.youtube.com") },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp)
                )

                Text(
                    text = "Select Site Category:",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF4CD7F6)
                )

                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    items(SiteCategory.values()) { category ->
                        FilterChip(
                            selected = selectedCategory == category,
                            onClick = { selectedCategory = category },
                            label = { Text(category.displayName, fontSize = 11.sp) }
                        )
                    }
                }

                if (!isVerified) {
                    if (showVerificationStep) {
                        val metaTag = com.example.data.DomainVerificationService.generateMetaTag(urlText)
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(Color(0xFF2D2A32), RoundedCornerShape(8.dp))
                                .padding(12.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Text(
                                "Domain Ownership Verification required. Please add this meta-tag to the <head> section of your website's HTML:",
                                fontSize = 11.sp,
                                color = Color(0xFFCBC3D7)
                            )
                            Text(
                                metaTag,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF4CD7F6),
                                modifier = Modifier
                                    .background(Color.Black, RoundedCornerShape(4.dp))
                                    .padding(8.dp)
                            )
                            var isVerifying by remember { mutableStateOf(false) }
                            var verificationError by remember { mutableStateOf<String?>(null) }
                            val scope = rememberCoroutineScope()
                            
                            Button(
                                onClick = {
                                    isVerifying = true
                                    verificationError = null
                                    scope.launch {
                                        val result = com.example.data.DomainVerificationService.verifyDomain(urlText, metaTag)
                                        isVerifying = false
                                        result.onSuccess {
                                            isVerified = true
                                        }.onFailure { error ->
                                            verificationError = error.message ?: "Verification failed."
                                        }
                                    }
                                },
                                modifier = Modifier.fillMaxWidth().height(40.dp),
                                enabled = !isVerifying,
                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF4ADE80))
                            ) {
                                if (isVerifying) {
                                    CircularProgressIndicator(modifier = Modifier.size(16.dp), strokeWidth = 2.dp, color = Color.Black)
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text("Verifying...", color = Color.Black, fontWeight = FontWeight.Bold)
                                } else {
                                    Text("Verify Now (Simulated)", color = Color.Black, fontWeight = FontWeight.Bold)
                                }
                            }
                            
                            if (verificationError != null) {
                                Text(
                                    text = "❌ $verificationError",
                                    fontSize = 11.sp,
                                    color = Color(0xFFF44336)
                                )
                            }
                        }
                    } else {
                        Button(
                            onClick = { showVerificationStep = true },
                            modifier = Modifier.fillMaxWidth(),
                            enabled = urlText.isNotBlank() && nameText.isNotBlank(),
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF4CD7F6))
                        ) {
                            Text("Initiate Verification", color = Color.Black, fontWeight = FontWeight.Bold)
                        }
                    }
                }

                if (isVerified) {
                    Text(
                        text = "✅ Domain Verified: $urlText belongs to you.",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF4ADE80)
                    )
                }

                if (isAnalyzing) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.padding(top = 8.dp)
                    ) {
                        CircularProgressIndicator(modifier = Modifier.size(20.dp), strokeWidth = 2.dp, color = Color(0xFF4CD7F6))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Analyzing domain traffic, speed score & crowd patterns...", fontSize = 11.sp, color = Color(0xFF4CD7F6))
                    }
                }

                if (analysisSuccess) {
                    Text(
                        text = "✅ Analysis Complete! Connected successfully.",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF4ADE80)
                    )
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (urlText.isNotBlank() && nameText.isNotBlank() && isVerified) {
                        onAnalyze(urlText, nameText, selectedCategory)
                    }
                },
                enabled = urlText.isNotBlank() && nameText.isNotBlank() && !isAnalyzing && isVerified,
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFA078FF))
            ) {
                Text("Analyze & Connect")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Close", color = Color(0xFFCBC3D7))
            }
        }
    )
}

@Composable
fun GlassCard(
    modifier: Modifier = Modifier,
    content: @Composable () -> Unit
) {
    Surface(
        modifier = modifier.animateContentSize(animationSpec = tween(350)),
        shape = RoundedCornerShape(18.dp),
        color = Color(0xFFFFFFFF).copy(alpha = 0.05f),
        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0x26FFFFFF))
    ) {
        content()
    }
}

@Composable
fun DetailRowItem(label: String, value: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 6.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(label, fontSize = 12.sp, color = Color(0xFF958EA0))
        Text(value, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color(0xFFE4E1E6))
    }
}

@Composable
fun SettingsRowItem(title: String, icon: ImageVector, onClick: () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
            .padding(12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, contentDescription = null, tint = Color(0xFF4CD7F6), modifier = Modifier.size(20.dp))
        Spacer(modifier = Modifier.width(12.dp))
        Text(title, fontSize = 14.sp, fontWeight = FontWeight.Bold, color = Color(0xFFE4E1E6), modifier = Modifier.weight(1f))
        Icon(Icons.Default.ArrowForward, contentDescription = null, tint = Color(0xFF958EA0), modifier = Modifier.size(16.dp))
    }
}

@Composable
fun CreateTicketModalDialog(
    onDismiss: () -> Unit,
    onSubmit: (title: String, desc: String, type: String, priority: com.example.model.TicketPriority) -> Unit
) {
    var titleText by remember { mutableStateOf("") }
    var descText by remember { mutableStateOf("") }
    var selectedType by remember { mutableStateOf("Bug Fix") }
    var selectedPriority by remember { mutableStateOf(com.example.model.TicketPriority.MEDIUM) }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Color(0xFF131316),
        title = {
            Text("Create Agency Workflow Ticket", fontWeight = FontWeight.Bold, color = Color(0xFFD0BCFF))
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("Submit technical issues, design changes, or speed optimizations directly to your agency dev team.", fontSize = 12.sp, color = Color(0xFFCBC3D7))

                OutlinedTextField(
                    value = titleText,
                    onValueChange = { titleText = it },
                    label = { Text("Ticket Title") },
                    placeholder = { Text("e.g. Optimize Homepage Hero Image") },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp)
                )

                OutlinedTextField(
                    value = descText,
                    onValueChange = { descText = it },
                    label = { Text("Description & Notes") },
                    placeholder = { Text("Describe the expected outcome...") },
                    modifier = Modifier.fillMaxWidth(),
                    minLines = 2,
                    shape = RoundedCornerShape(12.dp)
                )

                Text("Priority Level:", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color(0xFF4CD7F6))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    com.example.model.TicketPriority.values().forEach { priority ->
                        FilterChip(
                            selected = selectedPriority == priority,
                            onClick = { selectedPriority = priority },
                            label = { Text(priority.name, fontSize = 11.sp) }
                        )
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (titleText.isNotBlank()) {
                        onSubmit(titleText, descText, selectedType, selectedPriority)
                    }
                },
                enabled = titleText.isNotBlank(),
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF4CD7F6))
            ) {
                Text("Submit Ticket", color = Color(0xFF09090B), fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel", color = Color(0xFFCBC3D7))
            }
        }
    )
}

@Composable
fun AiSiteIntelligenceTrackingCard(
    website: Website,
    onReAnalyze: () -> Unit,
    onOpenPromo: () -> Unit
) {
    GlassCard(modifier = Modifier.fillMaxWidth()) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(28.dp)
                            .background(Color(0xFF4CD7F6).copy(alpha = 0.2f), CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.AutoAwesome,
                            contentDescription = "AI Engine",
                            tint = Color(0xFF4CD7F6),
                            modifier = Modifier.size(16.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Column {
                        Text(
                            text = "SITEPULSE AI ENGINE",
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF4CD7F6),
                            letterSpacing = 1.sp
                        )
                        Text(
                            text = "Live Website Intelligence & Tracking",
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                    }
                }

                IconButton(
                    onClick = onReAnalyze,
                    modifier = Modifier.size(32.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Refresh,
                        contentDescription = "Re-analyze with AI",
                        tint = Color(0xFFD0BCFF)
                    )
                }
            }

            HorizontalDivider(color = Color(0x1AFFFFFF))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text("SEO & SPEED SCORE", fontSize = 10.sp, color = Color(0xFFCBC3D7))
                    Text(
                        text = "${website.speedScore}/100",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF81C784)
                    )
                }
                Column(modifier = Modifier.weight(1f)) {
                    Text("CONVERSION RATE", fontSize = 10.sp, color = Color(0xFFCBC3D7))
                    Text(
                        text = "${website.conversionRate}%",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF4CD7F6)
                    )
                }
            }

            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color(0xFF1E1C24), RoundedCornerShape(10.dp))
                    .padding(10.dp)
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.TrendingUp,
                            contentDescription = null,
                            tint = Color(0xFFFFA726),
                            modifier = Modifier.size(14.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "AI CROWD SURGE FORECAST",
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFFFFA726)
                        )
                    }
                    Text(
                        text = website.peakCrowdHours,
                        fontSize = 12.sp,
                        color = Color(0xFFE4E1E6),
                        fontWeight = FontWeight.Medium
                    )
                }
            }

            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color(0xFF2A1B28), RoundedCornerShape(10.dp))
                    .padding(10.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f).padding(end = 8.dp)) {
                        Text(
                            text = "AI RECOMMENDED CAMPAIGN",
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFFD0BCFF)
                        )
                        Text(
                            text = website.activeBannerConfig,
                            fontSize = 12.sp,
                            color = Color.White,
                            fontWeight = FontWeight.SemiBold
                        )
                    }

                    OutlinedButton(
                        onClick = onOpenPromo,
                        shape = RoundedCornerShape(8.dp),
                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFD0BCFF))
                    ) {
                        Text("Deploy", fontSize = 11.sp, color = Color(0xFFD0BCFF), fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

@Composable
fun CreatePromoModalDialog(
    onDismiss: () -> Unit,
    onSubmit: (title: String) -> Unit
) {
    var promoTitle by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Color(0xFF131316),
        title = {
            Text("Launch Crowd Smart Promo Banner", fontWeight = FontWeight.Bold, color = Color(0xFFD0BCFF))
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("Triggers an auto-converting promotional overlay when crowd traffic spikes on your site.", fontSize = 12.sp, color = Color(0xFFCBC3D7))

                OutlinedTextField(
                    value = promoTitle,
                    onValueChange = { promoTitle = it },
                    label = { Text("Campaign Name / Offer Code") },
                    placeholder = { Text("e.g. FLASH20 - 20% Off Weekend Sale") },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp)
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (promoTitle.isNotBlank()) {
                        onSubmit(promoTitle)
                    }
                },
                enabled = promoTitle.isNotBlank(),
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFA078FF))
            ) {
                Text("Launch Campaign", color = Color.White, fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel", color = Color(0xFFCBC3D7))
            }
        }
    )
}


