package com.example.ui.theme

import androidx.compose.runtime.staticCompositionLocalOf
import com.example.viewmodel.ThemeViewModel

val LocalThemeViewModel = staticCompositionLocalOf<ThemeViewModel> {
    error("No ThemeViewModel provided")
}
