package com.example.ui.components

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.drawscope.translate
import kotlinx.coroutines.isActive
import kotlin.math.cos
import kotlin.math.sin
import kotlin.random.Random

data class Particle(
    var x: Float,
    var y: Float,
    var speedX: Float,
    var speedY: Float,
    val size: Float,
    val type: Int, // 0 = circle, 1 = cross, 2 = triangle, 3 = square
    val alpha: Float,
    var rotation: Float,
    val rotationSpeed: Float
)

@Composable
fun ParticleBackground(
    modifier: Modifier = Modifier,
    particleCount: Int = 30,
    backgroundColor: Color = MaterialTheme.colorScheme.background,
    particleColor: Color = MaterialTheme.colorScheme.primary.copy(alpha = 0.2f),
    content: @Composable () -> Unit
) {
    val particles = remember {
        List(particleCount) {
            Particle(
                x = Random.nextFloat(),
                y = Random.nextFloat(),
                speedX = (Random.nextFloat() - 0.5f) * 0.002f,
                speedY = (Random.nextFloat() - 0.5f) * 0.002f,
                size = Random.nextFloat() * 20f + 10f,
                type = Random.nextInt(4),
                alpha = Random.nextFloat() * 0.3f + 0.1f,
                rotation = Random.nextFloat() * 360f,
                rotationSpeed = (Random.nextFloat() - 0.5f) * 2f
            )
        }
    }

    var tick by remember { mutableStateOf(0f) }

    LaunchedEffect(Unit) {
        while (isActive) {
            withFrameMillis { 
                tick = it.toFloat()
                
                particles.forEach { p ->
                    p.x += p.speedX
                    p.y += p.speedY
                    p.rotation += p.rotationSpeed
                    
                    if (p.x < -0.1f) p.x = 1.1f
                    if (p.x > 1.1f) p.x = -0.1f
                    if (p.y < -0.1f) p.y = 1.1f
                    if (p.y > 1.1f) p.y = -0.1f
                }
            }
        }
    }

    Box(modifier = modifier.fillMaxSize().background(backgroundColor)) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val width = size.width
            val height = size.height
            
            // Draw gradient background or subtle grid
            val gridSize = 100f
            val gridColor = particleColor.copy(alpha = 0.05f)
            val stroke = Stroke(width = 1f)
            
            for (i in 0..(width / gridSize).toInt()) {
                drawLine(
                    color = gridColor,
                    start = Offset(i * gridSize, 0f),
                    end = Offset(i * gridSize, height),
                    strokeWidth = 1f
                )
            }
            for (i in 0..(height / gridSize).toInt()) {
                drawLine(
                    color = gridColor,
                    start = Offset(0f, i * gridSize),
                    end = Offset(width, i * gridSize),
                    strokeWidth = 1f
                )
            }

            // Draw particles
            particles.forEach { p ->
                val px = p.x * width
                val py = p.y * height
                
                translate(px, py) {
                    rotate(p.rotation) {
                        val color = particleColor.copy(alpha = p.alpha)
                        when (p.type) {
                            0 -> drawCircle(color = color, radius = p.size / 2, style = Stroke(width = 2f))
                            1 -> {
                                drawLine(color = color, start = Offset(-p.size/2, 0f), end = Offset(p.size/2, 0f), strokeWidth = 2f)
                                drawLine(color = color, start = Offset(0f, -p.size/2), end = Offset(0f, p.size/2), strokeWidth = 2f)
                            }
                            2 -> {
                                val path = Path().apply {
                                    moveTo(0f, -p.size/2)
                                    lineTo(p.size/2, p.size/2)
                                    lineTo(-p.size/2, p.size/2)
                                    close()
                                }
                                drawPath(path = path, color = color, style = Stroke(width = 2f))
                            }
                            3 -> {
                                drawRect(color = color, topLeft = Offset(-p.size/2, -p.size/2), size = androidx.compose.ui.geometry.Size(p.size, p.size), style = Stroke(width = 2f))
                            }
                        }
                    }
                }
            }
        }
        
        content()
    }
}
