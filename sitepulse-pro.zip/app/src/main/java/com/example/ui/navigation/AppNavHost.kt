package com.example.ui.navigation

import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.example.model.UserRole
import com.example.ui.screens.SplashScreen
import com.example.ui.screens.auth.AuthScreen
import com.example.ui.screens.auth.LoginScreen
import com.example.ui.screens.auth.SignUpScreen
import com.example.ui.screens.client.ClientDashboardScreen
import com.example.ui.screens.provider.AgencyDashboardScreen
import com.example.viewmodel.AuthViewModel

object Routes {
    const val SPLASH = "splash"
    const val LOGIN = "login"
    const val SIGN_UP = "sign_up"
    const val AUTH = "auth"
    const val CLIENT_DASHBOARD = "client_dashboard"
    const val PROVIDER_DASHBOARD = "provider_dashboard"
    const val PROFILE = "profile"
    const val CHAT = "chat"
}

@Composable
fun AppNavHost() {
    val navController = rememberNavController()
    val authViewModel: AuthViewModel = viewModel()
    val currentUser by authViewModel.currentUser.collectAsState()

    NavHost(navController = navController, startDestination = Routes.SPLASH) {
        composable(Routes.SPLASH) {
            SplashScreen(
                onSplashComplete = {
                    val nextRoute = when (currentUser?.role) {
                        UserRole.CLIENT -> Routes.CLIENT_DASHBOARD
                        UserRole.PROVIDER -> Routes.PROVIDER_DASHBOARD
                        else -> Routes.AUTH
                    }
                    navController.navigate(nextRoute) {
                        popUpTo(Routes.SPLASH) { inclusive = true }
                    }
                }
            )
        }
        composable(Routes.AUTH) {
            AuthScreen(
                authViewModel = authViewModel,
                onAuthSuccess = {
                    val targetRoute = if (currentUser?.role == UserRole.PROVIDER) {
                        Routes.PROVIDER_DASHBOARD
                    } else {
                        Routes.CLIENT_DASHBOARD
                    }
                    navController.navigate(targetRoute) {
                        popUpTo(Routes.AUTH) { inclusive = true }
                    }
                }
            )
        }
        composable(Routes.LOGIN) {
            LoginScreen(
                authViewModel = authViewModel,
                onNavigateToSignUp = { navController.navigate(Routes.AUTH) },
                onLoginSuccess = { role ->
                    val route = if (role == UserRole.CLIENT) Routes.CLIENT_DASHBOARD else Routes.PROVIDER_DASHBOARD
                    navController.navigate(route) {
                        popUpTo(Routes.LOGIN) { inclusive = true }
                    }
                }
            )
        }
        composable(Routes.SIGN_UP) {
            SignUpScreen(
                authViewModel = authViewModel,
                onNavigateToLogin = { navController.navigateUp() },
                onSignUpSuccess = { role ->
                    val route = if (role == UserRole.CLIENT) Routes.CLIENT_DASHBOARD else Routes.PROVIDER_DASHBOARD
                    navController.navigate(route) {
                        popUpTo(Routes.LOGIN) { inclusive = true }
                        popUpTo(Routes.SIGN_UP) { inclusive = true }
                    }
                }
            )
        }
        composable(Routes.CLIENT_DASHBOARD) {
            ClientDashboardScreen(
                onSignOut = {
                    authViewModel.logout()
                    navController.navigate(Routes.AUTH) {
                        popUpTo(Routes.CLIENT_DASHBOARD) { inclusive = true }
                    }
                },
                onNavigateToProfile = {
                    navController.navigate(Routes.PROFILE)
                },
                onNavigateToChat = {
                    navController.navigate(Routes.CHAT)
                },
                user = currentUser
            )
        }
        composable(Routes.PROVIDER_DASHBOARD) {
            AgencyDashboardScreen(
                onSignOut = {
                    authViewModel.logout()
                    navController.navigate(Routes.AUTH) {
                        popUpTo(Routes.PROVIDER_DASHBOARD) { inclusive = true }
                    }
                },
                onNavigateToProfile = {
                    navController.navigate(Routes.PROFILE)
                },
                onNavigateToChat = {
                    navController.navigate(Routes.CHAT)
                },
                user = currentUser
            )
        }
        composable(Routes.PROFILE) {
            com.example.ui.screens.profile.UserProfileScreen(
                authViewModel = authViewModel,
                onNavigateBack = {
                    navController.navigateUp()
                },
                onSignOut = {
                    navController.navigate(Routes.AUTH) {
                        popUpTo(0) { inclusive = true }
                    }
                }
            )
        }
        composable(Routes.CHAT) {
            com.example.ui.screens.chat.ChatScreen(
                currentUser = currentUser,
                onNavigateBack = {
                    navController.navigateUp()
                }
            )
        }
    }
}
