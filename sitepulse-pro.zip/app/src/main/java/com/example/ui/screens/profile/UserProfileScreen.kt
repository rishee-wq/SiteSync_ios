package com.example.ui.screens.profile

import android.app.Activity
import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.model.User
import com.example.model.UserRole
import com.example.viewmodel.AuthViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun UserProfileScreen(
    authViewModel: AuthViewModel = viewModel(),
    onNavigateBack: () -> Unit = {},
    onSignOut: () -> Unit = {}
) {
    val context = LocalContext.current
    val activity = context as? Activity

    val currentUser by authViewModel.currentUser.collectAsState()
    val loading by authViewModel.loading.collectAsState()

    var showEditNameDialog by remember { mutableStateOf(false) }
    var editNameInput by remember { mutableStateOf("") }

    var showLinkPhoneDialog by remember { mutableStateOf(false) }
    var countryCode by remember { mutableStateOf("+1") }
    var phoneInput by remember { mutableStateOf("") }
    var otpInput by remember { mutableStateOf("") }
    var isPhoneOtpSent by remember { mutableStateOf(false) }

    var showLinkEmailDialog by remember { mutableStateOf(false) }
    var emailInput by remember { mutableStateOf("") }

    var linkedAccounts by remember { mutableStateOf(authViewModel.getLinkedAccountsStatus()) }

    val linkedAccountsTrigger by authViewModel.linkedAccountsTrigger.collectAsState()

    // Refresh linked accounts on composition / user updates
    LaunchedEffect(currentUser, linkedAccountsTrigger) {
        linkedAccounts = authViewModel.getLinkedAccountsStatus()
    }

    com.example.ui.components.ParticleBackground(
        modifier = Modifier.fillMaxSize(),
        backgroundColor = MaterialTheme.colorScheme.background,
        particleColor = MaterialTheme.colorScheme.primary
    ) {
        Scaffold(
            topBar = {
            TopAppBar(
                title = {
                    Text(
                        "User Profile",
                        fontWeight = FontWeight.Bold
                    )
                },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back"
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = Color.Transparent
                )
            )
        },
        containerColor = Color.Transparent
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .imePadding()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp, vertical = 12.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            val name = currentUser?.name?.takeIf { it.isNotBlank() } ?: "User"
            val email = currentUser?.email?.takeIf { it.isNotBlank() } ?: "No Email Set"
            val companyName = currentUser?.companyName?.takeIf { it.isNotBlank() } ?: "Acme Corp"
            val role = currentUser?.role ?: UserRole.CLIENT

            // Profile Header Card
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.4f)
                )
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Box(
                        modifier = Modifier
                            .size(88.dp)
                            .clip(CircleShape)
                            .background(MaterialTheme.colorScheme.primary),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = name.take(2).uppercase(),
                            color = MaterialTheme.colorScheme.onPrimary,
                            fontSize = 32.sp,
                            fontWeight = FontWeight.ExtraBold
                        )
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.Center
                    ) {
                        Text(
                            text = name,
                            style = MaterialTheme.typography.headlineSmall,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        IconButton(
                            onClick = {
                                editNameInput = name
                                showEditNameDialog = true
                            },
                            modifier = Modifier.size(32.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Edit,
                                contentDescription = "Edit Display Name",
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }

                    Text(
                        text = email,
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    Row(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        AssistChip(
                            onClick = {},
                            label = {
                                Text(
                                    if (role == UserRole.PROVIDER) "Agency Provider" else "Client Account",
                                    fontWeight = FontWeight.SemiBold
                                )
                            },
                            leadingIcon = {
                                Icon(
                                    imageVector = if (role == UserRole.PROVIDER) Icons.Default.BusinessCenter else Icons.Default.Person,
                                    contentDescription = null,
                                    modifier = Modifier.size(16.dp)
                                )
                            }
                        )

                        AssistChip(
                            onClick = {},
                            label = { Text(companyName, fontWeight = FontWeight.Medium) },
                            leadingIcon = {
                                Icon(
                                    imageVector = Icons.Default.Domain,
                                    contentDescription = null,
                                    modifier = Modifier.size(16.dp)
                                )
                            }
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            // Account Information Details Section
            Text(
                text = "Account Details",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 8.dp)
            )

            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.35f))
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    ProfileDetailRow(
                        icon = Icons.Default.Badge,
                        label = "User ID (UID)",
                        value = currentUser?.uid?.takeIf { it.isNotBlank() } ?: "dummy_uid_12345"
                    )
                    HorizontalDivider(modifier = Modifier.padding(vertical = 12.dp), color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f))
                    ProfileDetailRow(
                        icon = Icons.Default.Person,
                        label = "Display Name",
                        value = name
                    )
                    HorizontalDivider(modifier = Modifier.padding(vertical = 12.dp), color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f))
                    ProfileDetailRow(
                        icon = Icons.Default.Email,
                        label = "Primary Email",
                        value = email
                    )
                    HorizontalDivider(modifier = Modifier.padding(vertical = 12.dp), color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f))
                    ProfileDetailRow(
                        icon = Icons.Default.Sync,
                        label = "MySQL Database Sync",
                        value = "Connected & Synced"
                    )
                }
            }

            Spacer(modifier = Modifier.height(24.dp))

            // Linked Accounts Management Section
            Text(
                text = "Linked Authentication Accounts",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 8.dp)
            )

            Text(
                text = "Manage your connected sign-in methods for multi-factor login access.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 12.dp)
            )

            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.35f))
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    linkedAccounts.forEachIndexed { index, account ->
                        LinkedAccountItem(
                            providerName = account.providerName,
                            icon = when (account.providerId) {
                                "google.com" -> Icons.Default.AccountCircle
                                "phone" -> Icons.Default.Phone
                                else -> Icons.Default.Email
                            },
                            isLinked = account.isLinked,
                            detail = account.detail,
                            onConnect = {
                                when (account.providerId) {
                                    "google.com" -> authViewModel.linkGoogleAccount(context)
                                    "phone" -> showLinkPhoneDialog = true
                                    else -> showLinkEmailDialog = true
                                }
                            }
                        )
                        if (index < linkedAccounts.size - 1) {
                            HorizontalDivider(
                                modifier = Modifier.padding(vertical = 12.dp),
                                color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f)
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(28.dp))

            // Logout Action Button
            OutlinedButton(
                onClick = {
                    authViewModel.logout()
                    onSignOut()
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp),
                shape = RoundedCornerShape(14.dp),
                colors = ButtonDefaults.outlinedButtonColors(contentColor = MaterialTheme.colorScheme.error)
            ) {
                Icon(
                    imageVector = Icons.Default.ExitToApp,
                    contentDescription = null,
                    modifier = Modifier.size(20.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text("Sign Out", fontWeight = FontWeight.Bold, fontSize = 16.sp)
            }

            Spacer(modifier = Modifier.height(32.dp))
        }
    }
    }

    // 1. Edit Display Name Dialog
    if (showEditNameDialog) {
        AlertDialog(
            onDismissRequest = { showEditNameDialog = false },
            title = { Text("Update Display Name", fontWeight = FontWeight.Bold) },
            text = {
                Column {
                    Text(
                        "Enter your updated full name for SitePulse:",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    OutlinedTextField(
                        value = editNameInput,
                        onValueChange = { editNameInput = it },
                        label = { Text("Full Name") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (editNameInput.isNotBlank()) {
                            authViewModel.updateDisplayName(editNameInput) { success ->
                                if (success) {
                                    Toast.makeText(context, "Display name updated!", Toast.LENGTH_SHORT).show()
                                    linkedAccounts = authViewModel.getLinkedAccountsStatus()
                                }
                            }
                            showEditNameDialog = false
                        }
                    },
                    enabled = !loading && editNameInput.isNotBlank()
                ) {
                    Text("Save Changes")
                }
            },
            dismissButton = {
                TextButton(onClick = { showEditNameDialog = false }) {
                    Text("Cancel")
                }
            }
        )
    }

    // 2. Link Phone Number Dialog
    if (showLinkPhoneDialog) {
        AlertDialog(
            onDismissRequest = {
                showLinkPhoneDialog = false
                isPhoneOtpSent = false
            },
            title = { Text("Link Phone Account", fontWeight = FontWeight.Bold) },
            text = {
                Column {
                    if (!isPhoneOtpSent) {
                        Text(
                            "Enter your mobile phone number to send a verification OTP code:",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            OutlinedTextField(
                                value = countryCode,
                                onValueChange = { countryCode = it },
                                label = { Text("Code") },
                                singleLine = true,
                                modifier = Modifier.width(80.dp)
                            )
                            OutlinedTextField(
                                value = phoneInput,
                                onValueChange = { phoneInput = it },
                                label = { Text("Phone Number") },
                                leadingIcon = { Icon(Icons.Default.Phone, contentDescription = null) },
                                singleLine = true,
                                modifier = Modifier.weight(1f)
                            )
                        }
                    } else {
                        val fullPhone = if (phoneInput.startsWith("+")) phoneInput else "$countryCode$phoneInput"
                        Text(
                            "Enter the 6-digit OTP verification code sent to $fullPhone:",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        OutlinedTextField(
                            value = otpInput,
                            onValueChange = { if (it.length <= 6) otpInput = it },
                            label = { Text("6-Digit OTP") },
                            leadingIcon = { Icon(Icons.Default.Lock, contentDescription = null) },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (!isPhoneOtpSent) {
                            if (phoneInput.length >= 7) {
                                activity?.let {
                                    val fullPhone = if (phoneInput.startsWith("+")) phoneInput else "$countryCode$phoneInput"
                                    authViewModel.sendPhoneOtp(it, fullPhone)
                                    isPhoneOtpSent = true
                                }
                            }
                        } else {
                            if (otpInput.length == 6) {
                                authViewModel.verifyPhoneOtp(otpInput)
                                Toast.makeText(context, "Phone number successfully linked!", Toast.LENGTH_SHORT).show()
                                showLinkPhoneDialog = false
                                isPhoneOtpSent = false
                                linkedAccounts = authViewModel.getLinkedAccountsStatus()
                            }
                        }
                    },
                    enabled = !loading && (if (!isPhoneOtpSent) phoneInput.length >= 7 else otpInput.length == 6)
                ) {
                    Text(if (!isPhoneOtpSent) "Send OTP" else "Verify & Link")
                }
            },
            dismissButton = {
                TextButton(onClick = {
                    showLinkPhoneDialog = false
                    isPhoneOtpSent = false
                }) {
                    Text("Cancel")
                }
            }
        )
    }

    // 3. Link Email Account Dialog
    if (showLinkEmailDialog) {
        AlertDialog(
            onDismissRequest = { showLinkEmailDialog = false },
            title = { Text("Link Email Address", fontWeight = FontWeight.Bold) },
            text = {
                Column {
                    Text(
                        "Enter your email address to associate with your profile:",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    OutlinedTextField(
                        value = emailInput,
                        onValueChange = { emailInput = it },
                        label = { Text("Email Address") },
                        leadingIcon = { Icon(Icons.Default.Email, contentDescription = null) },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (emailInput.isNotBlank()) {
                            Toast.makeText(context, "Email linked to your account!", Toast.LENGTH_SHORT).show()
                            showLinkEmailDialog = false
                            linkedAccounts = authViewModel.getLinkedAccountsStatus()
                        }
                    },
                    enabled = emailInput.isNotBlank()
                ) {
                    Text("Link Email")
                }
            },
            dismissButton = {
                TextButton(onClick = { showLinkEmailDialog = false }) {
                    Text("Cancel")
                }
            }
        )
    }
}

@Composable
fun ProfileDetailRow(
    icon: ImageVector,
    label: String,
    value: String
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .size(36.dp)
                .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.1f), CircleShape),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.primary,
                modifier = Modifier.size(20.dp)
            )
        }

        Spacer(modifier = Modifier.width(14.dp))

        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = label,
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Text(
                text = value,
                style = MaterialTheme.typography.bodyMedium,
                fontWeight = FontWeight.SemiBold,
                color = MaterialTheme.colorScheme.onSurface,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

@Composable
fun LinkedAccountItem(
    providerName: String,
    icon: ImageVector,
    isLinked: Boolean,
    detail: String?,
    onConnect: () -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .size(40.dp)
                .background(
                    if (isLinked) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant,
                    CircleShape
                ),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = if (isLinked) MaterialTheme.colorScheme.onPrimaryContainer else MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.size(22.dp)
            )
        }

        Spacer(modifier = Modifier.width(14.dp))

        Column(modifier = Modifier.weight(1f)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = providerName,
                    style = MaterialTheme.typography.bodyMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface
                )
                if (isLinked) {
                    Spacer(modifier = Modifier.width(6.dp))
                    Icon(
                        imageVector = Icons.Default.CheckCircle,
                        contentDescription = "Connected",
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(16.dp)
                    )
                }
            }

            Text(
                text = if (isLinked) (detail ?: "Connected") else "Not connected",
                style = MaterialTheme.typography.bodySmall,
                color = if (isLinked) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant
            )
        }

        if (!isLinked) {
            FilledTonalButton(
                onClick = onConnect,
                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
            ) {
                Text("Link", fontSize = 12.sp, fontWeight = FontWeight.Bold)
            }
        } else {
            Surface(
                shape = RoundedCornerShape(8.dp),
                color = MaterialTheme.colorScheme.primary.copy(alpha = 0.12f)
            ) {
                Text(
                    text = "Linked",
                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.primary,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}
