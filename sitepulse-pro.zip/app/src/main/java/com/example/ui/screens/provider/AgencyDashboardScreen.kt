package com.example.ui.screens.provider

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateContentSize
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.model.Ticket
import com.example.model.TicketPriority
import com.example.model.TicketStatus
import com.example.model.User
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AgencyDashboardScreen(
    onSignOut: () -> Unit,
    onNavigateToProfile: () -> Unit = {},
    onNavigateToChat: () -> Unit = {},
    user: User?,
    providerViewModel: com.example.viewmodel.ProviderViewModel = androidx.lifecycle.viewmodel.compose.viewModel()
) {
    val allTickets by providerViewModel.allTickets.collectAsState()
    var selectedTab by remember { mutableStateOf(0) }

    val deepZincBg = Color(0xFF09090B)
    val glassBorder = Color(0x26FFFFFF)

    com.example.ui.components.ParticleBackground(
        modifier = Modifier.fillMaxSize(),
        backgroundColor = deepZincBg,
        particleColor = Color(0xFF4CD7F6)
    ) {
        Scaffold(
            topBar = {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color(0xFF131316).copy(alpha = 0.95f))
                    .statusBarsPadding()
                    .padding(horizontal = 16.dp, vertical = 12.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .clip(CircleShape)
                            .background(
                                Brush.linearGradient(
                                    listOf(Color(0xFF4CD7F6), Color(0xFFA078FF))
                                )
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Public,
                            contentDescription = "Logo",
                            tint = Color(0xFF09090B),
                            modifier = Modifier.size(20.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(
                            text = "SitePulse Agency",
                            fontWeight = FontWeight.ExtraBold,
                            fontSize = 17.sp,
                            color = Color(0xFF4CD7F6),
                            letterSpacing = (-0.5).sp
                        )
                        Text(
                            text = "Partner Control Room",
                            fontSize = 10.sp,
                            color = Color(0xFF958EA0)
                        )
                    }
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = { selectedTab = 1 }) {
                        Icon(
                            imageVector = Icons.Default.Forum,
                            contentDescription = "Client Conversations",
                            tint = Color(0xFFD0BCFF)
                        )
                    }
                    IconButton(onClick = onNavigateToProfile) {
                        Icon(
                            imageVector = Icons.Default.AccountCircle,
                            contentDescription = "User Profile",
                            tint = Color(0xFFE4E1E6)
                        )
                    }
                    IconButton(onClick = onSignOut) {
                        Icon(
                            imageVector = Icons.Default.ExitToApp,
                            contentDescription = "Sign Out",
                            tint = Color(0xFF958EA0)
                        )
                    }
                }
            }
        },
        bottomBar = {
            NavigationBar(
                containerColor = Color(0xFF131316).copy(alpha = 0.95f),
                tonalElevation = 0.dp,
                modifier = Modifier.border(width = 1.dp, color = glassBorder)
            ) {
                val navItems = listOf(
                    Triple(0, Icons.Default.Home, "OVERVIEW"),
                    Triple(1, Icons.Default.Forum, "MESSAGES"),
                    Triple(2, Icons.Default.People, "CLIENTS"),
                    Triple(3, Icons.Default.Notifications, "REQUESTS"),
                    Triple(4, Icons.Default.Settings, "SETTINGS")
                )

                navItems.forEach { (index, icon, label) ->
                    val isSelected = selectedTab == index
                    NavigationBarItem(
                        icon = {
                            Icon(
                                icon,
                                contentDescription = label,
                                tint = if (isSelected) Color(0xFF4CD7F6) else Color(0xFF958EA0)
                            )
                        },
                        label = {
                            Text(
                                label,
                                fontSize = 10.sp,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                color = if (isSelected) Color(0xFF4CD7F6) else Color(0xFF958EA0)
                            )
                        },
                        selected = isSelected,
                        onClick = { selectedTab = index },
                        colors = NavigationBarItemDefaults.colors(
                            indicatorColor = Color.Transparent
                        )
                    )
                }
            }
        },
        containerColor = Color.Transparent
    ) { paddingValues ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .imePadding()
        ) {
            AnimatedContent(
                targetState = selectedTab,
                transitionSpec = {
                    if (targetState > initialState) {
                        (slideInHorizontally(animationSpec = tween(300)) { width -> width } + fadeIn(animationSpec = tween(300))) togetherWith
                        (slideOutHorizontally(animationSpec = tween(300)) { width -> -width } + fadeOut(animationSpec = tween(300)))
                    } else {
                        (slideInHorizontally(animationSpec = tween(300)) { width -> -width } + fadeIn(animationSpec = tween(300))) togetherWith
                        (slideOutHorizontally(animationSpec = tween(300)) { width -> width } + fadeOut(animationSpec = tween(300)))
                    }
                },
                label = "AgencyTabTransition"
            ) { targetTab ->
                when (targetTab) {
                    0 -> AgencyHomeTabContent(user = user)
                    1 -> com.example.ui.screens.chat.ChatScreen(currentUser = user)
                    2 -> AgencyClientsTabContent()
                    3 -> AgencyRequestsTabContent(allTickets = allTickets, providerViewModel = providerViewModel)
                    4 -> AgencySettingsTabContent(onSignOut = onSignOut, onNavigateToProfile = onNavigateToProfile)
                }
            }
        }
    }
    }
}

@Composable
fun AgencyHomeTabContent(
    user: User?
) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        contentPadding = PaddingValues(vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            AgencyGlassCard(modifier = Modifier.fillMaxWidth()) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "AGENCY PARTNER",
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF4CD7F6),
                            letterSpacing = 1.sp
                        )
                        Text(
                            text = user?.companyName?.takeIf { it.isNotBlank() } ?: "SitePulse Agency Partner",
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFFE4E1E6)
                        )
                        Text(
                            text = "Managing Active Client Sites & Real-time Crowd Operations",
                            fontSize = 12.sp,
                            color = Color(0xFFCBC3D7)
                        )
                    }
                }
            }
        }

        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                AgencyKpiCard(
                    modifier = Modifier.weight(1f),
                    title = "YouTube Activity",
                    value = "842K hrs",
                    subtitle = "+12% watch time",
                    icon = Icons.Default.PlayCircle,
                    accentColor = Color(0xFFF44336)
                )

                AgencyKpiCard(
                    modifier = Modifier.weight(1f),
                    title = "Active Client Sites",
                    value = "18 Live",
                    subtitle = "100% Uptime Grid",
                    icon = Icons.Default.Public,
                    accentColor = Color(0xFF4CD7F6)
                )
            }
        }
    }
}

@Composable
fun TicketItemCard(
    ticket: Ticket,
    onStatusUpdate: (TicketStatus) -> Unit
) {
    var isExpanded by remember { mutableStateOf(false) }

    val priorityColor = when (ticket.priority) {
        TicketPriority.URGENT -> Color(0xFFFFB4AB)
        TicketPriority.MEDIUM -> Color(0xFFF9A826)
        TicketPriority.LOW -> Color(0xFF4ADE80)
    }

    AgencyGlassCard(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { isExpanded = !isExpanded }
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = ticket.type.ifBlank { "Client Request" },
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF4CD7F6)
                )

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = ticket.priority.name,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = priorityColor,
                        modifier = Modifier
                            .clip(RoundedCornerShape(6.dp))
                            .background(priorityColor.copy(alpha = 0.15f))
                            .padding(horizontal = 8.dp, vertical = 2.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Icon(
                        imageVector = if (isExpanded) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
                        contentDescription = "Expand Ticket Details",
                        tint = Color(0xFF958EA0),
                        modifier = Modifier.size(18.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(6.dp))

            Text(
                text = ticket.title,
                fontSize = 15.sp,
                fontWeight = FontWeight.Bold,
                color = Color(0xFFE4E1E6)
            )

            Text(
                text = ticket.description,
                fontSize = 12.sp,
                color = Color(0xFFCBC3D7)
            )

            AnimatedVisibility(visible = isExpanded) {
                Column(modifier = Modifier.padding(top = 10.dp)) {
                    HorizontalDivider(color = Color(0x26FFFFFF))
                    Spacer(modifier = Modifier.height(8.dp))
                    Text("Ticket ID: ${ticket.ticketId.take(8)}...", fontSize = 11.sp, color = Color(0xFF958EA0))
                    Text("Client UID: ${ticket.clientUid.ifBlank { "Client Primary Account" }}", fontSize = 11.sp, color = Color(0xFF4CD7F6))
                    Text("Assigned Engineer: SitePulse Tier-2 DevOps", fontSize = 11.sp, color = Color(0xFFD0BCFF))
                    Text("SLA Response Window: < 15 mins", fontSize = 11.sp, color = Color(0xFF4ADE80))
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Status: ${ticket.status.name}",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFFD0BCFF)
                )

                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    if (ticket.status != TicketStatus.DEPLOYED) {
                        Button(
                            onClick = {
                                val next = when (ticket.status) {
                                    TicketStatus.SUBMITTED -> TicketStatus.IN_REVIEW
                                    TicketStatus.IN_REVIEW -> TicketStatus.IN_DEVELOPMENT
                                    TicketStatus.IN_DEVELOPMENT -> TicketStatus.DEPLOYED
                                    else -> TicketStatus.DEPLOYED
                                }
                                onStatusUpdate(next)
                            },
                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                            shape = RoundedCornerShape(8.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFA078FF))
                        ) {
                            Text("Advance Phase", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun AgencyClientsTabContent() {
    val clients = listOf(
        mapOf(
            "name" to "Tasty Bites Bistro",
            "domain" to "www.tastybitesbistro.com",
            "status" to "Active",
            "payments" to "Paid - $499/mo",
            "pastWork" to "SEO Optimization, Mobile Checkout Fix, Speed Boost",
            "uptime" to "99.9%"
        ),
        mapOf(
            "name" to "Acme Enterprise",
            "domain" to "www.acme-corp.com",
            "status" to "Active",
            "payments" to "Paid - $899/mo",
            "pastWork" to "Custom Landing Page, Authentication Setup",
            "uptime" to "100%"
        ),
        mapOf(
            "name" to "YouTube Metrics",
            "domain" to "www.youtube.com",
            "status" to "Monitoring",
            "payments" to "Trial",
            "pastWork" to "Analytics Integration, Crowd Mapping",
            "uptime" to "99.9%"
        )
    )

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        contentPadding = PaddingValues(vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Text(
                text = "CLIENT ROSTER & DOMAIN PORTFOLIO",
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                color = Color(0xFF4CD7F6),
                letterSpacing = 1.sp
            )
        }

        items(clients) { client ->
            var isExpanded by remember { mutableStateOf(false) }
            AgencyGlassCard(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { isExpanded = !isExpanded }
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(client["name"]!!, fontSize = 16.sp, fontWeight = FontWeight.Bold, color = Color(0xFFE4E1E6))
                            Text(client["domain"]!!, fontSize = 12.sp, color = Color(0xFF4CD7F6))
                        }
                        Icon(
                            imageVector = if (isExpanded) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
                            contentDescription = "Expand",
                            tint = Color(0xFF958EA0)
                        )
                    }

                    if (isExpanded) {
                        Spacer(modifier = Modifier.height(12.dp))
                        HorizontalDivider(color = Color(0x26FFFFFF))
                        Spacer(modifier = Modifier.height(12.dp))
                        
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("Status:", fontSize = 12.sp, color = Color(0xFF958EA0))
                            Text(client["status"]!!, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color(0xFF4ADE80))
                        }
                        Spacer(modifier = Modifier.height(6.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("Uptime Grid:", fontSize = 12.sp, color = Color(0xFF958EA0))
                            Text(client["uptime"]!!, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color(0xFFE4E1E6))
                        }
                        Spacer(modifier = Modifier.height(6.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("Payments:", fontSize = 12.sp, color = Color(0xFF958EA0))
                            Text(client["payments"]!!, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color(0xFFE4E1E6))
                        }
                        Spacer(modifier = Modifier.height(6.dp))
                        Column(modifier = Modifier.fillMaxWidth()) {
                            Text("Past Work / Operations:", fontSize = 12.sp, color = Color(0xFF958EA0))
                            Text(client["pastWork"]!!, fontSize = 12.sp, fontWeight = FontWeight.Medium, color = Color(0xFFD0BCFF))
                        }
                        
                        Spacer(modifier = Modifier.height(16.dp))
                        Button(
                            onClick = { /* Open Site or Send Message */ },
                            modifier = Modifier.fillMaxWidth().height(40.dp),
                            shape = RoundedCornerShape(8.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF4CD7F6))
                        ) {
                            Icon(Icons.Default.OpenInNew, contentDescription = null, tint = Color.Black, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Manage Client Account", color = Color.Black, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun AgencyRequestsTabContent(
    allTickets: List<Ticket>,
    providerViewModel: com.example.viewmodel.ProviderViewModel
) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        contentPadding = PaddingValues(vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            var selectedFilter by remember { mutableStateOf<TicketStatus?>(null) }
            
            Column {
                Text(
                    text = "CLIENT WORKFLOW TICKETS",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF4CD7F6),
                    letterSpacing = 1.sp,
                    modifier = Modifier.padding(start = 4.dp, top = 4.dp)
                )
                
                Row(
                    modifier = Modifier.fillMaxWidth().padding(top = 8.dp).horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    FilterChip(
                        selected = selectedFilter == null,
                        onClick = { selectedFilter = null },
                        label = { Text("All", fontSize = 11.sp) }
                    )
                    
                    TicketStatus.values().forEach { status ->
                        FilterChip(
                            selected = selectedFilter == status,
                            onClick = { selectedFilter = status },
                            label = { Text(status.name, fontSize = 11.sp) }
                        )
                    }
                }
            }
            
            val filteredTickets = if (selectedFilter == null) allTickets else allTickets.filter { it.status == selectedFilter }
            
            if (filteredTickets.isEmpty()) {
                Spacer(modifier = Modifier.height(16.dp))
                AgencyGlassCard(modifier = Modifier.fillMaxWidth()) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(24.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text("No tickets found for this filter.", color = Color(0xFFCBC3D7), fontSize = 13.sp)
                    }
                }
            } else {
                Spacer(modifier = Modifier.height(16.dp))
                Column(verticalArrangement = Arrangement.spacedBy(16.dp)) {
                    filteredTickets.forEach { ticket ->
                        TicketItemCard(
                            ticket = ticket,
                            onStatusUpdate = { newStatus ->
                                providerViewModel.updateTicketStatus(ticket.ticketId, newStatus)
                            }
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun AgencySettingsTabContent(onSignOut: () -> Unit, onNavigateToProfile: () -> Unit) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        contentPadding = PaddingValues(vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Text(
                text = "AGENCY SETTINGS & TEAM CONTROL",
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                color = Color(0xFF4CD7F6),
                letterSpacing = 1.sp
            )
        }

        item {
            val themeViewModel = com.example.ui.theme.LocalThemeViewModel.current
            val isDarkTheme by themeViewModel.isDarkTheme.collectAsStateWithLifecycle(initialValue = androidx.compose.foundation.isSystemInDarkTheme())
            
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 8.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("Dark Mode", color = MaterialTheme.colorScheme.onBackground)
                Switch(
                    checked = isDarkTheme ?: androidx.compose.foundation.isSystemInDarkTheme(),
                    onCheckedChange = { themeViewModel.toggleTheme(it) },
                    colors = SwitchDefaults.colors(
                        checkedThumbColor = Color.White,
                        checkedTrackColor = Color(0xFF4CD7F6),
                        uncheckedThumbColor = Color(0xFF8B7D9E),
                        uncheckedTrackColor = Color(0xFF262130)
                    )
                )
            }
        }

        item {
            Button(
                onClick = onSignOut,
                modifier = Modifier.fillMaxWidth().height(48.dp),
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF93000A))
            ) {
                Icon(Icons.Default.ExitToApp, contentDescription = null, tint = Color.White)
                Spacer(modifier = Modifier.width(8.dp))
                Text("Sign Out Agency Session", fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
fun AgencyGlassCard(modifier: Modifier = Modifier, content: @Composable () -> Unit) {
    Surface(
        modifier = modifier.animateContentSize(animationSpec = tween(350)),
        shape = RoundedCornerShape(18.dp),
        color = Color(0xFFFFFFFF).copy(alpha = 0.05f),
        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0x26FFFFFF))
    ) {
        content()
    }
}

@Composable
fun AgencyKpiCard(
    modifier: Modifier = Modifier,
    title: String,
    value: String,
    subtitle: String,
    icon: ImageVector,
    accentColor: Color
) {
    var isExpanded by remember { mutableStateOf(false) }

    AgencyGlassCard(modifier = modifier.clickable { isExpanded = !isExpanded }) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(icon, contentDescription = null, tint = accentColor, modifier = Modifier.size(20.dp))
                Icon(
                    imageVector = if (isExpanded) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
                    contentDescription = null,
                    tint = Color(0xFF958EA0),
                    modifier = Modifier.size(16.dp)
                )
            }
            Spacer(modifier = Modifier.height(8.dp))
            Text(title, fontSize = 11.sp, color = Color(0xFF958EA0))
            Text(value, fontSize = 20.sp, fontWeight = FontWeight.Bold, color = Color(0xFFE4E1E6))
            Text(subtitle, fontSize = 10.sp, color = accentColor)

            AnimatedVisibility(visible = isExpanded) {
                Column(modifier = Modifier.padding(top = 8.dp)) {
                    HorizontalDivider(color = Color(0x1AFFFFFF))
                    Spacer(modifier = Modifier.height(4.dp))
                    Text("System Health: 99.98%", fontSize = 10.sp, color = Color(0xFF4ADE80))
                    Text("Auto Scale Capacity: Nominal", fontSize = 10.sp, color = Color(0xFFCBC3D7))
                }
            }
        }
    }
}
