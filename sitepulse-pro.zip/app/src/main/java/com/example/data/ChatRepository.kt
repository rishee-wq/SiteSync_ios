package com.example.data

import com.example.model.ChatChannel
import com.example.model.ChatMessage
import com.example.model.User
import com.example.model.UserRole
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Query
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await

class ChatRepository {
    private val firestore: FirebaseFirestore? by lazy {
        try {
            FirebaseFirestore.getInstance()
        } catch (e: Exception) {
            null
        }
    }

    /**
     * Get channels accessible to the user based on role
     */
    fun getChannelsForUser(user: User?): Flow<List<ChatChannel>> = callbackFlow {
        val userUid = user?.uid ?: "dummy_client"
        val isProvider = user?.role == UserRole.PROVIDER

        val db = firestore ?: run {
            trySend(emptyList())
            awaitClose {}
            return@callbackFlow
        }

        val query = if (isProvider) {
            db.collection("chat_channels")
                .orderBy("lastMessageTime", Query.Direction.DESCENDING)
        } else {
            db.collection("chat_channels")
                .whereEqualTo("clientUid", userUid)
                .orderBy("lastMessageTime", Query.Direction.DESCENDING)
        }

        val listener = query.addSnapshotListener { snapshot, error ->
            if (error != null) {
                trySend(emptyList())
                return@addSnapshotListener
            }
            if (snapshot != null) {
                val channels = snapshot.toObjects(ChatChannel::class.java)
                if (channels.isEmpty() && !isProvider) {
                    // Auto-create a default AI Copilot channel for client if none exists
                    val defaultChannel = ChatChannel(
                        channelId = "channel_ai_$userUid",
                        clientUid = userUid,
                        clientName = user?.companyName?.ifBlank { user?.name?.ifBlank { "Client Company" } } ?: "Client Company",
                        agencyUid = "agency_ai_engine",
                        agencyName = "🤖 SitePulse AI Engine Copilot",
                        lastMessage = "Hello! I am your 24/7 AI Operations Copilot. Ask me anything about your website traffic or conversion health!",
                        lastMessageTime = System.currentTimeMillis()
                    )
                    
                    val agencyChannel = ChatChannel(
                        channelId = "channel_agency_$userUid",
                        clientUid = userUid,
                        clientName = user?.companyName?.ifBlank { user?.name?.ifBlank { "Client Company" } } ?: "Client Company",
                        agencyUid = "agency_primary",
                        agencyName = "SitePulse Digital Agency",
                        lastMessage = "Welcome to your direct agency support channel.",
                        lastMessageTime = System.currentTimeMillis() - 1000
                    )

                    db.collection("chat_channels").document(defaultChannel.channelId).set(defaultChannel)
                    db.collection("chat_channels").document(agencyChannel.channelId).set(agencyChannel)
                    
                    // Add welcome messages
                    val welcomeMsg1 = ChatMessage(
                        messageId = "msg_${System.currentTimeMillis()}_1",
                        channelId = defaultChannel.channelId,
                        senderUid = "agency_ai_engine",
                        senderName = "🤖 SitePulse AI Engine",
                        senderRole = UserRole.PROVIDER,
                        text = defaultChannel.lastMessage,
                        timestamp = defaultChannel.lastMessageTime,
                        isRead = false
                    )
                    db.collection("chat_channels").document(defaultChannel.channelId)
                        .collection("messages").document(welcomeMsg1.messageId).set(welcomeMsg1)

                    val welcomeMsg2 = ChatMessage(
                        messageId = "msg_${System.currentTimeMillis()}_2",
                        channelId = agencyChannel.channelId,
                        senderUid = "agency_primary",
                        senderName = "Sarah Jenkins (Account Director)",
                        senderRole = UserRole.PROVIDER,
                        text = agencyChannel.lastMessage,
                        timestamp = agencyChannel.lastMessageTime,
                        isRead = false
                    )
                    db.collection("chat_channels").document(agencyChannel.channelId)
                        .collection("messages").document(welcomeMsg2.messageId).set(welcomeMsg2)
                    
                    trySend(listOf(defaultChannel, agencyChannel))
                } else {
                    trySend(channels)
                }
            }
        }
        awaitClose { listener.remove() }
    }

    /**
     * Get Real-time messages for a given channel
     */
    fun getMessagesForChannel(channelId: String): Flow<List<ChatMessage>> = callbackFlow {
        val db = firestore ?: run {
            trySend(emptyList())
            awaitClose {}
            return@callbackFlow
        }
        val listener = db.collection("chat_channels")
            .document(channelId)
            .collection("messages")
            .orderBy("timestamp", Query.Direction.ASCENDING)
            .addSnapshotListener { snapshot, error ->
                if (error != null) {
                    trySend(emptyList())
                    return@addSnapshotListener
                }
                if (snapshot != null) {
                    val messages = snapshot.toObjects(ChatMessage::class.java)
                    trySend(messages)
                }
            }
        awaitClose { listener.remove() }
    }

    /**
     * Send a Chat Message
     */
    suspend fun sendMessage(
        channelId: String,
        sender: User,
        text: String,
        attachmentUrl: String? = null
    ): Result<Unit> {
        val message = ChatMessage(
            messageId = "msg_${System.currentTimeMillis()}",
            channelId = channelId,
            senderUid = sender.uid.ifBlank { "dummy_user" },
            senderName = sender.name.ifBlank { if (sender.role == UserRole.PROVIDER) "Agency Specialist" else "Client Representative" },
            senderRole = sender.role,
            text = text,
            timestamp = System.currentTimeMillis(),
            isRead = false,
            attachmentUrl = attachmentUrl
        )

        return try {
            val db = firestore ?: throw IllegalStateException("Firestore not available")
            
            val msgDocRef = db.collection("chat_channels")
                .document(channelId)
                .collection("messages")
                .document()

            val msgToSave = message.copy(messageId = msgDocRef.id)
            msgDocRef.set(msgToSave).await()

            // Update parent channel details
            db.collection("chat_channels").document(channelId).update(
                mapOf(
                    "lastMessage" to text,
                    "lastMessageTime" to message.timestamp
                )
            ).await()

            // Simulate Agency AI/Support Automated Response after 1.2s if sent by CLIENT
            if (sender.role == UserRole.CLIENT) {
                CoroutineScope(Dispatchers.IO).launch {
                    delay(1200)
                    val isAiChannel = channelId.startsWith("channel_ai_")
                    val autoReplyText = if (isAiChannel) {
                        com.example.data.GeminiAiEngine.askAiCopilot(text, "SitePulse Channel $channelId")
                    } else {
                        getSimulatedAgencyReply(text)
                    }

                    val autoReply = ChatMessage(
                        messageId = "msg_reply_${System.currentTimeMillis()}",
                        channelId = channelId,
                        senderUid = if (isAiChannel) "agency_ai_engine" else "agency_primary",
                        senderName = if (isAiChannel) "🤖 SitePulse AI Engine" else "Sarah Jenkins (Account Director)",
                        senderRole = UserRole.PROVIDER,
                        text = autoReplyText,
                        timestamp = System.currentTimeMillis(),
                        isRead = false
                    )

                    val replyRef = db.collection("chat_channels")
                        .document(channelId)
                        .collection("messages")
                        .document(autoReply.messageId)
                    
                    replyRef.set(autoReply).await()

                    // Update channel last message
                    db.collection("chat_channels").document(channelId).update(
                        mapOf(
                            "lastMessage" to autoReplyText,
                            "lastMessageTime" to autoReply.timestamp
                        )
                    ).await()
                }
            }

            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    private fun getSimulatedAgencyReply(userText: String): String {
        val lower = userText.lowercase()
        return when {
            lower.contains("status") || lower.contains("update") || lower.contains("website") ->
                "Thanks for reaching out! Our design and dev teams are actively monitoring your site performance. Current uptime is 100% with optimized response times."
            lower.contains("campaign") || lower.contains("ads") || lower.contains("clicks") ->
                "Your active campaigns are currently yielding a 4.2% CTR! We'll send over the weekly performance summary report shortly."
            lower.contains("ticket") || lower.contains("bug") || lower.contains("issue") ->
                "I've logged this directly with our engineering sprint board. Your ticket priority has been elevated to High!"
            lower.contains("call") || lower.contains("meeting") || lower.contains("schedule") ->
                "I'd be happy to schedule a strategy sync with our account lead! Let us know your preferred time slots for tomorrow."
            else ->
                "Thank you for your message! Our agency team has received this and will follow up with you right away."
        }
    }
}
