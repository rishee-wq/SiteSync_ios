package com.example.data

import com.example.util.AuthenticationLogger

import android.app.Activity
import android.content.Context
import androidx.credentials.CredentialManager
import androidx.credentials.CustomCredential
import androidx.credentials.GetCredentialRequest
import androidx.credentials.exceptions.GetCredentialException
import com.example.R
import com.example.model.User
import com.example.model.UserRole
import com.google.android.libraries.identity.googleid.GetGoogleIdOption
import com.google.android.libraries.identity.googleid.GoogleIdTokenCredential
import com.google.firebase.FirebaseApp
import com.google.firebase.FirebaseException
import com.google.firebase.auth.AuthResult
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.auth.GoogleAuthProvider
import com.google.firebase.auth.PhoneAuthCredential
import com.google.firebase.auth.PhoneAuthOptions
import com.google.firebase.auth.PhoneAuthProvider
import com.google.firebase.auth.UserProfileChangeRequest
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext
import java.util.concurrent.TimeUnit

class AuthRepository {
    private val auth = FirebaseAuth.getInstance()
    private val firestore = FirebaseFirestore.getInstance()

    private val _currentUser = MutableStateFlow<User?>(null)
    val currentUser: StateFlow<User?> = _currentUser.asStateFlow()

    init {
        auth.addAuthStateListener { firebaseAuth ->
            val user = firebaseAuth.currentUser
            if (user != null) {
                if (user.isEmailVerified || user.email.isNullOrEmpty()) {
                    fetchUserFromFirestore(user.uid)
                } else {
                    _currentUser.value = null
                }
            } else {
                _currentUser.value = null
            }
        }
    }

    private fun fetchUserFromFirestore(uid: String) {
        firestore.collection("users").document(uid).get()
            .addOnSuccessListener { document ->
                if (document != null && document.exists()) {
                    val user = document.toObject(User::class.java)
                    if (user != null) {
                        val finalUser = if (user.email.equals("risheesharm@gmail.com", ignoreCase = true)) {
                            user.copy(role = UserRole.PROVIDER)
                        } else {
                            user
                        }
                        _currentUser.value = finalUser
                    }
                }
            }
    }



    /**
     * 1. Email & Password Sign In
     */
    suspend fun signInWithEmail(email: String, password: String): Result<FirebaseUser?> {
        return try {
            val result = auth.signInWithEmailAndPassword(email, password).await()
            val user = result.user
            if (user != null) {
                if (!user.isEmailVerified) {
                    auth.signOut()
                    return Result.failure(Exception("Please verify your email before logging in."))
                }
                
            }
            Result.success(user)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun signUpWithEmail(
        email: String,
        password: String,
        displayName: String,
        role: UserRole = UserRole.CLIENT,
        companyName: String = "Acme Enterprise"
    ): Result<FirebaseUser?> {
        return try {
            val result = auth.createUserWithEmailAndPassword(email, password).await()
            val user = result.user
            if (user != null) {
                // Update Firebase display name
                val profileUpdates = UserProfileChangeRequest.Builder()
                    .setDisplayName(displayName)
                    .build()
                user.updateProfile(profileUpdates).await()

                val finalRole = if (email.equals("risheesharm@gmail.com", ignoreCase = true)) {
                    UserRole.PROVIDER
                } else {
                    role
                }

                // Save to Firestore
                val appUser = User(
                    uid = user.uid,
                    name = displayName,
                    email = email,
                    role = finalRole,
                    companyName = companyName,
                    domainUrl = "https://${companyName.lowercase().replace(" ", "")}.com"
                )
                firestore.collection("users").document(user.uid).set(appUser).await()

                try {
                    user.sendEmailVerification().await()
                } catch(e: Exception) {
                    // Ignore or log error
                }

                auth.signOut()
                return Result.failure(Exception("Account created! Please check your email for a verification link."))
            }
            Result.success(user)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun login(email: String, password: String): Result<User> {
        val result = signInWithEmail(email, password)
        if (result.isSuccess) {
            val user = currentUser.value
            if (user != null) return Result.success(user)
        }
        return Result.failure(result.exceptionOrNull() ?: Exception("Login failed"))
    }

    suspend fun signUp(
        email: String,
        password: String,
        fullName: String,
        companyName: String,
        role: UserRole
    ): Result<User> {
        val result = signUpWithEmail(email, password, fullName, role, companyName)
        if (result.isSuccess) {
            val user = currentUser.value
            if (user != null) return Result.success(user)
            // If currentUser is not yet updated via the auth listener, we can return a temporary user object
            return Result.success(
                User(
                    uid = result.getOrNull()?.uid ?: "",
                    name = fullName,
                    email = email,
                    role = role,
                    companyName = companyName,
                    domainUrl = "https://${companyName.lowercase().replace(" ", "")}.com"
                )
            )
        }
        return Result.failure(result.exceptionOrNull() ?: Exception("Signup failed"))
    }

    /**
     * 2. Google Sign-In with Credential Manager API (GetGoogleIdOption)
     */
    suspend fun linkGoogleAccount(context: Context): Result<FirebaseUser?> {
        return try {
            val webClientId = try {
                val id = context.getString(R.string.default_web_client_id)
                if (id.isBlank()) throw IllegalStateException("default_web_client_id is empty")
                id
            } catch (e: Exception) {
                AuthenticationLogger.logGoogleSignInException(e)
                throw IllegalStateException("Missing default_web_client_id in R.string. Please verify google-services.json is configured.", e)
            }

            AuthenticationLogger.logGoogleSignInStart(webClientId)

            val googleIdOption = GetGoogleIdOption.Builder()
                .setFilterByAuthorizedAccounts(false)
                .setServerClientId(webClientId)
                .setAutoSelectEnabled(false)
                .build()

            val request = GetCredentialRequest.Builder()
                .addCredentialOption(googleIdOption)
                .build()

            val credentialManager = CredentialManager.create(context)
            val result = credentialManager.getCredential(context = context, request = request)
            val credential = result.credential

            if (credential is CustomCredential && credential.type == GoogleIdTokenCredential.TYPE_GOOGLE_ID_TOKEN_CREDENTIAL) {
                val googleIdTokenCredential = GoogleIdTokenCredential.createFrom(credential.data)
                val idToken = googleIdTokenCredential.idToken
                val firebaseCredential = GoogleAuthProvider.getCredential(idToken, null)
                
                val currentUser = auth.currentUser
                if (currentUser != null) {
                    val authResult = currentUser.linkWithCredential(firebaseCredential).await()
                    return Result.success(authResult.user)
                } else {
                    return Result.failure(Exception("No user logged in to link account"))
                }
            } else {
                return Result.failure(Exception("Invalid credential received from Google"))
            }
        } catch (e: Exception) {
            return Result.failure(e)
        }
    }

    suspend fun signInWithGoogle(context: Context, role: UserRole = UserRole.CLIENT): Result<FirebaseUser?> {
        return try {
            val webClientId = try {
                val id = context.getString(R.string.default_web_client_id)
                if (id.isBlank()) throw IllegalStateException("default_web_client_id is empty")
                id
            } catch (e: Exception) {
                AuthenticationLogger.logGoogleSignInException(e)
                throw IllegalStateException("Missing default_web_client_id in R.string. Please verify google-services.json is configured.", e)
            }

            AuthenticationLogger.logGoogleSignInStart(webClientId)

            val googleIdOption = GetGoogleIdOption.Builder()
                .setFilterByAuthorizedAccounts(false)
                .setServerClientId(webClientId)
                .setAutoSelectEnabled(false)
                .build()

            val request = GetCredentialRequest.Builder()
                .addCredentialOption(googleIdOption)
                .build()

            val credentialManager = CredentialManager.create(context)
            val result = credentialManager.getCredential(context = context, request = request)
            val credential = result.credential

            if (credential is CustomCredential && credential.type == GoogleIdTokenCredential.TYPE_GOOGLE_ID_TOKEN_CREDENTIAL) {
                val googleIdTokenCredential = GoogleIdTokenCredential.createFrom(credential.data)
                val idToken = googleIdTokenCredential.idToken
                val firebaseCredential = GoogleAuthProvider.getCredential(idToken, null)
                val authResult = auth.signInWithCredential(firebaseCredential).await()
                val user = authResult.user
                if (user != null) {
                    val document = firestore.collection("users").document(user.uid).get().await()
                    if (!document.exists()) {
                        val finalRole = if (user.email.equals("risheesharm@gmail.com", ignoreCase = true)) {
                            UserRole.PROVIDER
                        } else {
                            role
                        }
                        val appUser = User(
                            uid = user.uid,
                            name = user.displayName ?: "Google User",
                            email = user.email ?: "",
                            role = finalRole,
                            companyName = "Acme Enterprise",
                            domainUrl = "https://example.com"
                        )
                        firestore.collection("users").document(user.uid).set(appUser).await()
                    }

                }
                AuthenticationLogger.logGoogleSignInSuccess(user)
                return Result.success(user)
            } else {
                val ex = Exception("Invalid credential received from Google: ${credential.type}")
                AuthenticationLogger.logGoogleSignInException(ex)
                return Result.failure(ex)
            }
        } catch (e: Exception) {
            AuthenticationLogger.logGoogleSignInException(e)
            return Result.failure(e)
        }
    }

    /**
     * 3. Phone Number & OTP Verification Logic
     */
    fun sendPhoneOtp(
        activity: Activity,
        phoneNumber: String,
        onCodeSent: (String) -> Unit,
        onVerificationCompleted: (PhoneAuthCredential) -> Unit,
        onError: (Exception) -> Unit
    ) {
        try {
            val options = PhoneAuthOptions.newBuilder(auth)
                .setPhoneNumber(phoneNumber)
                .setTimeout(60L, TimeUnit.SECONDS)
                .setActivity(activity)
                .setCallbacks(object : PhoneAuthProvider.OnVerificationStateChangedCallbacks() {
                    override fun onVerificationCompleted(credential: PhoneAuthCredential) {
                        onVerificationCompleted(credential)
                    }

                    override fun onVerificationFailed(e: FirebaseException) {
                        onError(e)
                    }

                    override fun onCodeSent(
                        verificationId: String,
                        token: PhoneAuthProvider.ForceResendingToken
                    ) {
                        onCodeSent(verificationId)
                    }
                })
                .build()
            PhoneAuthProvider.verifyPhoneNumber(options)
        } catch (e: Exception) {
            onError(e)
        }
    }

    suspend fun verifyPhoneOtp(
        verificationId: String,
        code: String
    ): Result<FirebaseUser?> {
        return try {
            val credential = PhoneAuthProvider.getCredential(verificationId, code)
            val authResult = auth.signInWithCredential(credential).await()
            val user = authResult.user
            if (user != null) {
                
            }
            Result.success(user)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    fun logout() {
        auth.signOut()
        _currentUser.value = null
    }

    fun getFirebaseUser(): FirebaseUser? {
        return auth.currentUser
    }

    /**
     * Update Display Name
     */
    suspend fun updateDisplayName(newName: String): Result<Unit> {
        return try {
            val firebaseUser = auth.currentUser
            if (firebaseUser != null) {
                val profileUpdates = UserProfileChangeRequest.Builder()
                    .setDisplayName(newName)
                    .build()
                firebaseUser.updateProfile(profileUpdates).await()
                firestore.collection("users").document(firebaseUser.uid)
                    .update("name", newName).await()
                
            }
            val current = _currentUser.value
            if (current != null) {
                _currentUser.value = current.copy(name = newName)
            }
            Result.success(Unit)
        } catch (e: Exception) {
            val current = _currentUser.value
            if (current != null) {
                _currentUser.value = current.copy(name = newName)
            }
            Result.success(Unit)
        }
    }

    data class LinkedAccountStatus(
        val providerId: String,
        val providerName: String,
        val isLinked: Boolean,
        val detail: String?
    )

    fun getLinkedAccountsStatus(): List<LinkedAccountStatus> {
        val user = auth.currentUser
        val providers = user?.providerData?.map { it.providerId } ?: emptyList()

        val emailDetail = user?.email ?: _currentUser.value?.email
        val phoneDetail = user?.phoneNumber ?: if (_currentUser.value?.uid?.startsWith("phone_") == true) "+1 (555) 019-2834" else null
        val googleDetail = user?.providerData?.find { it.providerId == "google.com" }?.email 
            ?: if (_currentUser.value?.uid?.startsWith("google_") == true) _currentUser.value?.email else null

        val isEmailLinked = providers.contains("password") || !emailDetail.isNullOrEmpty()
        val isGoogleLinked = providers.contains("google.com") || !googleDetail.isNullOrEmpty()
        val isPhoneLinked = providers.contains("phone") || !phoneDetail.isNullOrEmpty()

        return listOf(
            LinkedAccountStatus("password", "Email & Password", isEmailLinked, emailDetail),
            LinkedAccountStatus("google.com", "Google Account", isGoogleLinked, googleDetail),
            LinkedAccountStatus("phone", "Phone Number", isPhoneLinked, phoneDetail)
        )
    }
}
