package com.example.data

import com.example.model.Campaign
import com.example.model.CampaignStatus
import com.example.model.Ticket
import com.example.model.TicketPriority
import com.example.model.TicketStatus
import com.example.model.Website
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Query
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.tasks.await

class FirestoreRepository {
    private val firestore: FirebaseFirestore? by lazy {
        try {
            FirebaseFirestore.getInstance()
        } catch (e: Exception) {
            null
        }
    }

    fun getWebsite(clientUid: String): Flow<Website?> = callbackFlow {
        val db = firestore ?: run {
            trySend(null)
            awaitClose {}
            return@callbackFlow
        }
        val listener = db.collection("websites").document(clientUid)
            .addSnapshotListener { snapshot, error ->
                if (error != null) {
                    trySend(null)
                    return@addSnapshotListener
                }
                if (snapshot != null && snapshot.exists()) {
                    val website = snapshot.toObject(Website::class.java)
                    trySend(website)
                } else {
                    trySend(null)
                }
            }
        awaitClose { listener.remove() }
    }

    suspend fun saveWebsite(website: Website): Result<Unit> {
        return try {
            firestore?.collection("websites")?.document(website.clientUid)
                ?.set(website)?.await()
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    fun getTicketsForClient(clientUid: String): Flow<List<Ticket>> = callbackFlow {
        val db = firestore ?: run {
            trySend(emptyList())
            awaitClose {}
            return@callbackFlow
        }
        val listener = db.collection("tickets")
            .whereEqualTo("clientUid", clientUid)
            .orderBy("createdAt", Query.Direction.DESCENDING)
            .addSnapshotListener { snapshot, error ->
                if (error != null) {
                    trySend(emptyList())
                    return@addSnapshotListener
                }
                if (snapshot != null) {
                    val tickets = snapshot.toObjects(Ticket::class.java)
                    trySend(tickets)
                }
            }
        awaitClose { listener.remove() }
    }

    fun getAllTickets(): Flow<List<Ticket>> = callbackFlow {
        val db = firestore ?: run {
            trySend(emptyList())
            awaitClose {}
            return@callbackFlow
        }
        val listener = db.collection("tickets")
            .orderBy("createdAt", Query.Direction.DESCENDING)
            .addSnapshotListener { snapshot, error ->
                if (error != null) {
                    trySend(emptyList())
                    return@addSnapshotListener
                }
                if (snapshot != null) {
                    val tickets = snapshot.toObjects(Ticket::class.java)
                    trySend(tickets)
                }
            }
        awaitClose { listener.remove() }
    }

    suspend fun createTicket(ticket: Ticket): Result<Unit> {
        val newId = if (ticket.ticketId.isBlank()) "t_${System.currentTimeMillis()}" else ticket.ticketId
        val finalTicket = ticket.copy(ticketId = newId, createdAt = System.currentTimeMillis(), updatedAt = System.currentTimeMillis())

        return try {
            firestore?.collection("tickets")?.document(newId)?.set(finalTicket)?.await()
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun updateTicketStatus(ticketId: String, status: TicketStatus): Result<Unit> {
        return try {
            firestore?.collection("tickets")?.document(ticketId)
                ?.update("status", status, "updatedAt", System.currentTimeMillis())?.await()
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    fun getCampaignsForClient(clientUid: String): Flow<List<Campaign>> = callbackFlow {
        val db = firestore ?: run {
            trySend(emptyList())
            awaitClose {}
            return@callbackFlow
        }
        val listener = db.collection("campaigns")
            .whereEqualTo("clientUid", clientUid)
            .orderBy("createdAt", Query.Direction.DESCENDING)
            .addSnapshotListener { snapshot, error ->
                if (error != null) {
                    trySend(emptyList())
                    return@addSnapshotListener
                }
                if (snapshot != null) {
                    val campaigns = snapshot.toObjects(Campaign::class.java)
                    trySend(campaigns)
                }
            }
        awaitClose { listener.remove() }
    }

    suspend fun createCampaign(campaign: Campaign): Result<Unit> {
        val newId = if (campaign.campaignId.isBlank()) "camp_${System.currentTimeMillis()}" else campaign.campaignId
        val finalCampaign = campaign.copy(campaignId = newId)

        return try {
            firestore?.collection("campaigns")?.document(newId)?.set(finalCampaign)?.await()
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
}
