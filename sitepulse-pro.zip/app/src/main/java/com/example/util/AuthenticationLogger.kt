package com.example.util

import android.util.Log
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.crashlytics.FirebaseCrashlytics

object AuthenticationLogger {
    private const val TAG = "AuthenticationLogger"

    private val crashlytics: FirebaseCrashlytics by lazy {
        FirebaseCrashlytics.getInstance()
    }

    fun initAuthStateListener(auth: FirebaseAuth = FirebaseAuth.getInstance()) {
        try {
            auth.addAuthStateListener { firebaseAuth ->
                val user = firebaseAuth.currentUser
                if (user != null) {
                    logAuthState("AUTH_STATE_CHANGED", "User logged in: UID=${user.uid}, Email=${user.email}")
                    crashlytics.setUserId(user.uid)
                } else {
                    logAuthState("AUTH_STATE_CHANGED", "User logged out")
                    crashlytics.setUserId("")
                }
            }
        } catch (e: Exception) {
            logAuthException("initAuthStateListener", e)
        }
    }

    fun logAuthState(event: String, message: String) {
        val formattedLog = "[$event] $message"
        Log.i(TAG, formattedLog)
        try {
            crashlytics.log(formattedLog)
            crashlytics.setCustomKey("last_auth_event", event)
        } catch (e: Exception) {
            Log.e(TAG, "Crashlytics logging failed", e)
        }
    }

    fun logGoogleSignInStart(webClientId: String) {
        logAuthState("GOOGLE_SIGN_IN_START", "Starting Credential Manager request with Web Client ID: $webClientId")
    }

    fun logGoogleSignInSuccess(user: FirebaseUser?) {
        logAuthState(
            "GOOGLE_SIGN_IN_SUCCESS",
            "Google sign-in succeeded for user UID: ${user?.uid}, Email: ${user?.email}"
        )
    }

    fun logGoogleSignInException(e: Throwable) {
        Log.e(TAG, "Google Sign-In failed or was interrupted", e)
        try {
            crashlytics.log("[GOOGLE_SIGN_IN_ERROR] ${e.localizedMessage}")
            crashlytics.setCustomKey("google_sign_in_error", e.javaClass.simpleName)
            crashlytics.recordException(e)
        } catch (ex: Exception) {
            Log.e(TAG, "Failed recording exception to Crashlytics", ex)
        }
    }

    fun logAuthException(operation: String, e: Throwable) {
        Log.e(TAG, "Auth Operation failed: $operation", e)
        try {
            crashlytics.log("[AUTH_ERROR][$operation] ${e.localizedMessage}")
            crashlytics.recordException(e)
        } catch (ex: Exception) {
            Log.e(TAG, "Failed recording exception to Crashlytics", ex)
        }
    }
}
