package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.ThemePreferences
import com.example.ui.navigation.AppNavHost
import com.example.ui.theme.LocalThemeViewModel
import com.example.ui.theme.SitePulseTheme
import com.example.viewmodel.ThemeViewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        
        enableEdgeToEdge()
        val themePreferences = ThemePreferences(applicationContext)
        val themeViewModel = ThemeViewModel(themePreferences)
        
        setContent {
            val isDarkTheme by themeViewModel.isDarkTheme.collectAsStateWithLifecycle()
            val systemTheme = isSystemInDarkTheme()
            val useDarkTheme = isDarkTheme ?: systemTheme
            
            SitePulseTheme(darkTheme = useDarkTheme) {
                CompositionLocalProvider(LocalThemeViewModel provides themeViewModel) {
                    AppNavHost()
                }
            }
        }
    }
}
